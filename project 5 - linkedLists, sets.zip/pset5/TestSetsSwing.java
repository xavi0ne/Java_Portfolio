import java.awt.*;
import javax.swing.*;
import java.util.Scanner;
import java.awt.event.*;

/**
*@author: Xavier Torres
*@version: last updated 11_12_24
*@credit: Core Java: Fundamentals, Vol. 1
*              by: Cay Horstmann
*              Ch 11, section 11.2.1 & 11.2.3
*/

/**
 * the TestSetsSwing class is a swing implementation of TestSets.java
 * and performs the same program operations within a graphical user
 * interface (GUI) instead of the traditional console. 
 * 
 */
public class TestSetsSwing {

    private static final String TITLE = "Test Sets Program";
    private static final String SET_A = "Create Set A ";
    private static final String SET_B = "Create Set B ";
    private static final String INTERSECTION = "A * B (Intersection)";
    private static final String UNION = "A + B (Union)";
    private static final String DIFFERENCE = "A - B (Difference)";
    private static final String CARDINALITY_SET_A = "Cardinality A ";
    private static final String CARDINALITY_SET_B = "Cardinality B ";
    private static final String SUBSET_A = "A subset B? ";
    private static final String SUBSET_B = "B subset A? ";

    

    public static void main(String[] args) {

        SetsFrame setsFrame = new SetsFrame(TITLE);
        setsFrame.setVisible(true);
    }
/**
 * 
 * the SetsFrame is an inner class that is leveraged to build the window
 * frame, widgets, and listeners required to make the program function 
 * as a GUI. 
 */
    static class SetsFrame extends JFrame implements ActionListener {

        Bitset setA = new Bitset(16);
        Bitset setB = new Bitset(8);
        
        private static final int WIDTH = 300, HEIGHT = 300;

        private JTextArea output;
        private JButton set_A, set_B, intersection, union, difference, 
            cardinalityA, cardinalityB, subsetA, subsetB, clear;
        private JLabel setALabel, setBLabel;

/**
 * Constructor for the SetsFrame inner class.
 * @param title
 */
        public SetsFrame (String title) {

            widgets();
            layoutComponents(title);
            addListeners();

        }
/**
 * the 'widgets()' method performs the operations to build the 
 * interface, to include creating the buttons, text area, font 
 * style and size.  
 */
        private void widgets() {

            output = new JTextArea();
            output.setEditable(false);
            output.setFont(new Font("Monospaced", Font.PLAIN, 12));

            set_A = new JButton(SET_A);
            set_B = new JButton(SET_B);
            intersection = new JButton(INTERSECTION);
            union = new JButton(UNION);
            difference = new JButton(DIFFERENCE);
            cardinalityA = new JButton(CARDINALITY_SET_A);
            cardinalityB = new JButton(CARDINALITY_SET_B);
            subsetA = new JButton(SUBSET_A);
            subsetB = new JButton(SUBSET_B);
            clear = new JButton("Clear");
            
        }
/**
 * the 'layoutComponents()' method performs the operations to 
 * build the window frame layout to include setting the labels,
 * the layout style, the panels and their respective position
 * within the window frame. 
 * @param title
 */
        private void layoutComponents(String title) {

            this.setTitle(title);
            setSize(WIDTH, HEIGHT);
            setLayout(new BorderLayout());
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            setALabel = new JLabel("Set A: " + setA.toString());
            setBLabel = new JLabel("Set B: " + setA.toString());

            JPanel topPanel = new JPanel();
            topPanel.setLayout(new GridLayout(2, 1));
            topPanel.add(setALabel);
            topPanel.add(setBLabel);

            JPanel midPanel = new JPanel();
            midPanel.setLayout(new GridLayout(6, 2));
            midPanel.add(set_A);
            midPanel.add(set_B);
            midPanel.add(intersection);
            midPanel.add(union);
            midPanel.add(difference);
            midPanel.add(cardinalityA);
            midPanel.add(cardinalityB);
            midPanel.add(subsetA);
            midPanel.add(subsetB);
            midPanel.add(clear);

            add(topPanel, BorderLayout.NORTH);
            add(midPanel, BorderLayout.CENTER);
            add(new JScrollPane(output), BorderLayout.SOUTH);
        }
/**
 * the 'addListerner()' method performs the operations for 
 * each button created to call the 'addActionListener()' method. 
 * This enables the actions to be performed for each button as 
 * specified in the 'actionPerformed()' method.
 */
        private void addListeners() {
            
            set_A.addActionListener(this);
            set_B.addActionListener(this);
            intersection.addActionListener(this);
            union.addActionListener(this);
            difference.addActionListener(this);
            cardinalityA.addActionListener(this);
            cardinalityB.addActionListener(this);
            subsetA.addActionListener(this);
            subsetB.addActionListener(this);
            clear.addActionListener(this);
        }

/**
 * the 'executeActions()' method performs the operations
 * using switch to enable the actions for the buttons within
 * the window. Each case calls the respective method and 
 * executes the action as specified in the 'actionPerformed()'
 * method. 
 * @param action
 */
        private void executeActions(String action) {

            switch (action) {

                case SET_A:
                    createSets(SET_A);
                    break;
                case SET_B:
                    createSets(SET_B);
                    break;
                case INTERSECTION:
                    intersection();
                    break;
                case UNION:
                    union();
                    break;
                case DIFFERENCE:
                    difference();
                    break;
                case CARDINALITY_SET_A:
                    displayCardinalityA();
                    break;
                case CARDINALITY_SET_B:
                    displayCardinalityB();
                    break;
                case SUBSET_A:
                    checkSubsetA();
                    break;
                case SUBSET_B:
                    checkSubsetB();
                    break;
            }
        }
/**
 * 
 *the 'actionPerformed()' method performs the operations of 
 executing the actions via conditional expression for each 
 button created. The action executed mainly takes the input
 values added by the user and performs the method operations from 
 the BitSet class, followed by a message dialog with the 
 results. 
 * @param ae
 */
        public void actionPerformed(ActionEvent ae) {

            String command = ae.getActionCommand();
            executeActions(command);
            
            if (ae.getSource() == intersection) {

                executeActions(command);
                JOptionPane.showMessageDialog(this, INTERSECTION + setA.intersect(setB));

            } else if(ae.getSource() == union) {

                executeActions(command);
                JOptionPane.showMessageDialog(this, UNION + setA.union(setB));

            } else if(ae.getSource() == difference) {

                executeActions(command);
                JOptionPane.showMessageDialog(this, DIFFERENCE + setA.difference(setB));

            } else if (ae.getSource() == cardinalityA) {

                executeActions(command);
                JOptionPane.showMessageDialog(this, CARDINALITY_SET_A + setA.cardinality());
            } else if (ae.getSource() == cardinalityB) {

                executeActions(command);
                JOptionPane.showMessageDialog(this, CARDINALITY_SET_B + setB.cardinality());

            } else if (ae.getSource() == subsetA) {

                executeActions(command);
                JOptionPane.showMessageDialog(this, SUBSET_A + setA.isSubset(setB));

            } else if (ae.getSource() == subsetB) {

                executeActions(command);
                JOptionPane.showMessageDialog(this, SUBSET_B + setB.isSubset(setA));
            
            } else if (ae.getSource() == clear) {

                setA.clear();
                setB.clear();
                updateLabels();
                output.setText("");
                JOptionPane.showMessageDialog(this, "Set A and B and textField have been cleared.");
            }
           
        }
/**
 * the 'createSets()' method performs the operations of prompting the 
 * user to input the integer values upon clicking the buttons to create
 * set A or set B and takes that input to validate it is within the expected
 * range using the 'try-catch' to control error handling on proper number
 * format. 
 *  @param setName
 */
        private void createSets(String setName) {

            String input = JOptionPane.showInputDialog(this, "Type some small integer for " + setName);

            if (input != null && !input.isEmpty()) {

                String[] inputs = input.split("[,\\s]+");
                for (String str : inputs) {

                    try {

                        int num = Integer.parseInt(str.trim());
                        if (setName.equals(SET_A) && num >= 0 && num < 16) {

                            setA.include(num);
                        } else if (setName.equals(SET_B) && num >= 0 && num < 8) {

                            setB.include(num);
                        } 
                    } catch (NumberFormatException nfe) {

                    }
                }
            }
            updateLabels();
        }
/** 
 * the 'updateLabels()' method performs the updates
 * for the display label on the window for set A and B.
 */
        private void updateLabels() {

            setALabel.setText("Set A: " + setA.toString());
            setBLabel.setText("Set B: " + setB.toString());
        }
/**
 * the 'intersection()' method performs the call to the 
 * respective method in Bitset class to perform the 
 * required bitset operation as specified. 
 */
        private void intersection() {

            Bitset intersection = setA.intersect(setB);
            output.setText("A * B (Intersection): " + intersection.toString());
        }
/**
 * the 'union()' method performs the call to the 
 * respective method in Bitset class to perform the 
 * required bitset operation as specified. 
 */
        private void union() {

            Bitset union = setA.union(setB);
            output.setText("A + B (Union): " + union.toString());
        }
/**
 * the 'difference()' method performs the call to the 
 * respective method in Bitset class to perform the 
 * required bitset operation as specified. 
 */
        private void difference() {

            Bitset difference = setA.difference(setB);
            output.setText("A - B (Difference): " + difference.toString());
        }
/**
 * the 'displayCardinalityA()' method performs the call to the 
 * respective method in Bitset class to perform the 
 * required bitset operation as specified. 
 */
        private void displayCardinalityA() {

            output.setText("Cardinality of Set A: " + setA.cardinality());
        }
/**
 * the 'displayCardinalityB()' method performs the call to the 
 * respective method in Bitset class to perform the 
 * required bitset operation as specified. 
 */
        private void displayCardinalityB() {

            output.setText("Cardinality of Set B: " + setB.cardinality());
        }
/**
 * the 'checkSubsetA()' method performs the call to the 
 * respective method in Bitset class to perform the 
 * required bitset operation as specified. 
 */
        private void checkSubsetA() {

            boolean isSubset = setA.isSubset(setB);
            output.setText("Is A a subset of B? " + (isSubset ? true : false));
        }
/**
 * the 'checkSubsetB()' method performs the call to the 
 * respective method in Bitset class to perform the 
 * required bitset operation as specified. 
 */
        private void checkSubsetB() {

            boolean isSubset = setB.isSubset(setA);
            output.setText("Is B a subset of A? " + (isSubset ? true : false));
        }
    }
}