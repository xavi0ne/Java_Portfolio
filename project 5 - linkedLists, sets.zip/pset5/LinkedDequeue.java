/**
* @author: Xavier Torres
* @version: last updated 11_25_24
* @credit: Building Java Programs 5 Ed.
*          by: Stuart Reges and Marty Stepp
*          Ch 16.3
**/

/**
 * 
 * the LinkedDequeue class performs several method operations
 * to allow data structure to receive add-ins of new elements
 * to either end of the node as well as to remove an element from 
 * either end. 
 */
public class LinkedDequeue {

    private QueueNode tail;
    private QueueNode head;
    private int count;

/**
 * the inner class QueueNode which provides the variables that 
 * pertain to the node to reference the data and the next link. 
 */
    class QueueNode {

        private Object item;
        private QueueNode link;
    }
/**
 * 
 * the DequeueUnderFlowException is an inner class that is a subclass 
 * of Exception and used to develop a custom handling exception within the
 * LinkedDequeue class structure. 
 */
    public static class DequeueUnderFlowException extends Exception {

        public DequeueUnderFlowException(String message) {

            super(message);
        }
    }
/**
 * the constructor of the LinkedDequeue class that provides
 * indirect access to the private variables without the ability 
 * to modify them in any way. 
 */
    public LinkedDequeue () {

        tail = head = null;
        count = 0;
    }
/**
 * the headAdd() performs add-ins for new elements to the front 
 * of the queue by leveraging the QueueNode object and referencing
 * the next link. 
 */
    public void headAdd(Object o) {

        QueueNode nextNode = new QueueNode();
        nextNode.item = o;
        nextNode.link = head;
        head = nextNode;

        if (tail == null) {

            tail = head;
        }
        count++;
    }
/**
 * 
 * the 'headPeek()' method performs checks on the queue towards the 
 * front to validate if there are any elements. It leverages the custom
 * exception created for error handling control to inform when the queue is empty. 
 * @return
 * @throws DequeueUnderFlowException
 */
    public Object headPeek() throws DequeueUnderFlowException {

        if (isEmpty()) {

            throw new DequeueUnderFlowException("Dequeue is empty.");
        }
        return head.item;
    }

/*
 * the 'headRemove()' method performs operations to remove an element 
 * from the front of the queue. It leverages the custom exception created 
 * for error handling control to inform when the queue is empty. 
 */
    public Object headRemove () throws DequeueUnderFlowException {

        if ( isEmpty()) {

            throw new DequeueUnderFlowException("Dequeue is empty.");

        } else {

            Object tempItem = head.item;
            head = head.link;

            if (head == null) {

                tail = null;
                count --;
            }
            return tempItem;
        }
    }
/* the 'tailAdd()' performs operations to add an element to the rear
 * of the queue by using the QueueNode object to insert the data and 
 * reference the next link.
 */
    public void tailAdd (Object o) {

        QueueNode temp = new QueueNode();
        temp.item = o;
        temp.link = null;

        if (tail == null) {
            
            head = tail = temp;
        } else {

            tail.link = temp;
            tail = temp;
        }
        count++;
    }
/**
 * 
 * the 'get2ndToLastNode()' is a helper method and 
 * performs operations to check if there are any elements
 * in between the last element. Should the element be empty, it 
 * then returns null. It uses a while loop to check the current
 * and previous elements to validate. 
 * @return
 */
    private QueueNode get2ndToLastNode() {

        if (isEmpty()) {

            return null;
        }

        QueueNode current = head;
        QueueNode prev = null;

        while (current != null && current.link != null) {

            prev = current;
            current = current.link;
        }
        return prev;
    }
/**
 * 
 * the 'tailPeek()' performs operations to check the tail of 
 * the queue if there are any elements without removing them. 
 * It leverages the custom exception created for error handling 
 * control to inform when the queue is empty. 
 * @return
 * @throws DequeueUnderFlowException
 */
    public Object tailPeek() throws DequeueUnderFlowException {

        if (isEmpty()) {

            throw new DequeueUnderFlowException("Dequeue is empty.");
        }

        QueueNode current = head;

        while (current != null && current.link != null) {

            current = current.link;
        }
        QueueNode the2ndtoLast = get2ndToLastNode();
        System.out.printf("get2ndToLastNode() = %s\n", (the2ndtoLast != null ? the2ndtoLast.item: "null"));

        return current.item;
    }
/**
 * 
 * the 'tailRemove()' performs operations to remove an element from 
 * the rear of the queue using the while loop. It leverages the custom
 * exception created for error handling control to inform when the queue 
 * is empty. 
 * @return
 * @throws DequeueUnderFlowException
 */
    public Object tailRemove() throws DequeueUnderFlowException {

        if (isEmpty()) {

            throw new DequeueUnderFlowException("Dequeue is empty.");
        }

        if (head == tail) {

            Object tempObject = tail.item;
            head = tail = null;
            count--;
            return tempObject;
        }

        QueueNode theOne = head;

        while (theOne.link != tail) {

            theOne = theOne.link;
        }

        Object tempObject = tail.item;
        theOne.link = null;
        tail = theOne;
        count--;
        return tempObject;
    }

/**
 * the 'isEmpty()' method performs checks to validate
 * if the queue is indeed empty and returns the result
 * whether empty queue is true or false. 
 * @return
 */
    public boolean isEmpty() {

        return (count == 0);
    }
/**
 * the 'sie()' method performs operations to validate the 
 * size of the queue and return the result of how many. 
 * @return
 */
    public int size() {

        return count;
    }
/**
 * the 'to String()' method performs operations to return 
 * a formatted String representing the queue and its elements. 
 * This is done using the StringBuilder object instance. 
 */
    public String toString() {

        StringBuilder sb = new StringBuilder();
        QueueNode theOne = head;

        sb.append("[");

        while (theOne != null) {

            sb.append(theOne.item);
            if (theOne.link != null) {

                sb.append(", ");
            }
            theOne = theOne.link;
        }
        sb.append("]");

        return sb.toString();
    }
}