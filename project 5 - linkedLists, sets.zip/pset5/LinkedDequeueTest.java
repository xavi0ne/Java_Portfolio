/**
* @author: Xavier Torres
* @version: last updated 11_25_24
* @credit: Building Java Programs 5 Ed.
*          by: Stuart Reges and Marty Stepp
*          Ch 16.3
**/

/**
 * 
 * the LinkedDequeueTest is a class that performs testing 
 * on the LinkedDequeue class by calling the methods to output
 * the results after method operations. The method calls are 
 * set to demonstrate the method actions from the LinkedDequeue class
 * and try-catch is used for error handling on the custom exception 
 * created. 
 */
public class LinkedDequeueTest {

    public static void main(String [] args) {

        LinkedDequeue list = new LinkedDequeue();

        System.out.printf("Initial List check if empty: " + list);
        
        list.headAdd("One");
        list.headAdd("Two");
        list.headAdd("Three");

        System.out.println();
        System.out.printf("List check after additions: %s\n", list);
        System.out.println("Expected result: [Three, Two, One]\n");

        System.out.printf("size() = List has %d entries.\n", list.size());
        System.out.printf("list contents: %s\n", list);

        try {

            System.out.printf("headPeak() = %s\n", list.headPeek());
            System.out.println();
            System.out.printf("Is 'Two' at the head? %b\n",  list.headPeek().equals("Two"));
            System.out.printf("Is 'Three' at the head? %b\n", list.headPeek().equals("Three"));
            System.out.println();
        
        } catch (LinkedDequeue.DequeueUnderFlowException dufe) {

            System.out.println("Error: " + dufe.getMessage());

        }
        
        try {

            System.out.printf("tailPeek() = %s\n", list.tailPeek());
        
        } catch (LinkedDequeue.DequeueUnderFlowException dufe) {

            System.out.println("Error: " + dufe.getMessage());

        } 

        try {

            System.out.printf("headRemove() = %s\n", list.headRemove());
        
        } catch (LinkedDequeue.DequeueUnderFlowException dufe ) {

            System.out.println("Error: " + dufe.getMessage());
        }

        try {

            System.out.printf("tailRemove() = %s\n", list.tailRemove());
        
        } catch (LinkedDequeue.DequeueUnderFlowException dufe) {

            System.out.println("Error: " + dufe.getMessage());

        }
        System.out.println();
        System.out.printf("List check after removals: %s\n", list);
        System.out.println("Expected result: [Two]\n");
        System.out.printf("isEmpty() = %b\n",  list.isEmpty());
    }
}