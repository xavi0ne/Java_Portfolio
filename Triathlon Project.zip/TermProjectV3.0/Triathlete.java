import java.util.ArrayList;

class Triathlete {

    private String name;
    private int age;
    private double weight;
    private double height;
    private ArrayList<TrainingSession> trainingSessions;

    public Triathlete() {

        this.trainingSessions = new ArrayList<>();
    }

    public String getName() {

        return name;
    }

    public int getAge() {

        return age;
    }

    public double getWeight() {

        return weight;
    }

    public double getHeight() {

        return height;
    }

    public void setName(String name) {

        this.name = name;
    }

    public void setAge(int age) {

        this.age = age;
    }

    public void setWeight(double weight) {

        this.weight = weight;
    }

    public void setHeight(double height) {

        this.height = height;
    }

    public void addTrainingSession(TrainingSession session) {

        trainingSessions.add(session);
    }

    public double getTotalTrainingTime() {

        double total = 0;
        for (TrainingSession session : trainingSessions) {

            total += session.getTime();
        }
        return total;
    }

    public ArrayList<TrainingSession> getTrainingSessions() {

        return trainingSessions;
    }
}