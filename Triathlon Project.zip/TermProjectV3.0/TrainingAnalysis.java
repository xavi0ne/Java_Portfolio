public class TrainingAnalysis {

    public String predictRaceOutcome(TrainingSession[] sessions, Triathlete athlete) {

        if (sessions == null || sessions.length == 0) {

            return "No training data available for prediction.";
        }
        
        double totalSwimTime = 0, totalBikeTime = 0, totalRunTime = 0;
        double totalSwimSpeed = 0, totalBikeSpeed = 0, totalRunSpeed = 0;
        int swimCount = 0, bikeCount = 0, runCount = 0;

        for (TrainingSession session : sessions) {
            if (session != null) {

                switch( session.getEventType().toLowerCase()) {

                    case "swim": 
                        totalSwimTime += session.getTime();
                        totalSwimSpeed += session.getSpeed();
                        swimCount++;
                        break;
                    case "bike":
                        totalBikeTime += session.getTime();
                        totalBikeSpeed += session.getSpeed();
                        bikeCount++;
                        break;
                    case "run":
                        totalRunTime += session.getTime();
                        totalRunSpeed += session.getSpeed();
                        runCount++;
                        break;
                    default:
                        break;
                }
            }
        }

       
        double averageSwimSpeed = (swimCount > 0) ? (totalSwimSpeed / swimCount) : 0;
        double averageBikeSpeed = (bikeCount > 0) ? (totalBikeSpeed / bikeCount) : 0;
        double averageRunSpeed = (runCount > 0) ? (totalRunSpeed / runCount) : 0;
        
        if (averageSwimSpeed == 0 || averageBikeSpeed == 0 || averageRunSpeed == 0) {

            return "Insufficient data to calculate average speed for all events.";
        }

        double weightFactor = Math.max(0.8, Math.min(1.2, athlete.getWeight() / 70.0));       //measured in kilograms.
        double heightFactor = Math.max(0.8, Math.min(1.2, athlete.getHeight() / 175.0));
        int age = athlete.getAge();
        double ageFactor = (100 - age) / 100.0;

        System.out.println("Weight Factor: " + weightFactor);
        System.out.println("Height Factor: " + heightFactor);
        System.out.println("Age: " + age);
        System.out.println("Age Factor (100 - age) / 100: " + ((100 - age) / 100.0));

        double swimDistanceKm = 1.93;
        double bikeDistanceKm = 90.12;
        double runDistanceKm = 21.08;

        double swimPrediction = swimDistanceKm / averageSwimSpeed * 60;
        double bikePrediction = bikeDistanceKm / averageBikeSpeed * 60;
        double runPrediction = runDistanceKm / averageRunSpeed * 60;

        System.out.println("Swim Prediction Time: " + swimPrediction);
        System.out.println("Bike Prediction Time: " + bikePrediction);
        System.out.println("Run Prediction Time: " + runPrediction);

        //double adjustedSwimTime = swimPrediction * weightFactor * heightFactor * ageFactor * 1.0;
        //double adjustedBikeTime = bikePrediction * weightFactor * heightFactor * ageFactor * 1.0;
        //double adjustedRunTime = runPrediction * weightFactor * heightFactor * ageFactor * 1.0;


        double adjustedSwimTime = swimPrediction * (1 + (weightFactor - 1.0) * 0.5) * (1 + (heightFactor - 1.0) * 0.5) * (1 + (ageFactor - 1.0) * 0.5);
        double adjustedBikeTime = bikePrediction * (1 + (weightFactor - 1.0) * 0.5) * (1 + (heightFactor - 1.0) * 0.5) * (1 + (ageFactor - 1.0) * 0.5);
        double adjustedRunTime = runPrediction * (1 + (weightFactor - 1.0) * 0.5) * (1 + (heightFactor - 1.0) * 0.5) * (1 + (ageFactor - 1.0) * 0.5);
        
        System.out.println("Adjusted Swim Prediction Time: " + adjustedSwimTime);
        System.out.println("Adjusted Bike Prediction Time: " + adjustedBikeTime);
        System.out.println("Adjusted Run Prediction Time: " + adjustedRunTime);

        double totalPrediction = adjustedSwimTime + adjustedBikeTime + adjustedRunTime;

        double transitionTime = 8;

        totalPrediction += transitionTime;

        int totalHours = (int) totalPrediction / 60;
        int totalMinutes = (int) totalPrediction % 60;

        StringBuilder result = new StringBuilder();

        result.append(String.format("| %-15s | %-4s | %-20s |\n","Name", "Age", "Total Time (hrs:min)"));
        result.append("-------------------------------------------------------------\n");
        result.append(String.format("| %-15s | %-4s | %d:%02d |\n", athlete.getName(), age, totalHours, totalMinutes));

        return result.toString();
        //return String.format("Predicted race day time: %.2f minutes", totalPrediction);
    }
}