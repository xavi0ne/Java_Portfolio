import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.border.Border;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.*;


public class TriathleteTrainingProgram {

    private static final String TITLE = "Triathlete Training Program";

    public static void main(String[] args) {

        TriFrame triFrame = new TriFrame(TITLE);
        triFrame.setVisible(true);
    }

    static class TriFrame extends JFrame implements ActionListener {

        private static final int WIDTH = 500, HEIGHT = 500;

        private JTextField nameField, ageField, weightField, heightField;
        private JTextField eventTypeField, distanceField, timeField, speedField; 
        private JButton submit, add, analyze, importCSV;
        private JPanel gridPanel;
        private Triathlete triathlete;
        private TrainingSession[] sessions;
        private TrainingAnalysis trainingAnalysis;
        private int sessionCount;

        public TriFrame() {


        }
        public TriFrame(String title) {

            triathlete = new Triathlete();
            trainingAnalysis = new TrainingAnalysis();
            sessions = new TrainingSession[9];
            layoutComponents(title);
            addListeners();
            setResizable(false);
            sessionCount = 0;
        }

        private void layoutComponents(String title) {

            this.setTitle(title);
            setSize(WIDTH, HEIGHT);
            setLayout(new BorderLayout());

            ImageIcon logo = new ImageIcon("./tri.jpg");
            Image scaledImage = logo.getImage().getScaledInstance(WIDTH / 2, HEIGHT / 2, Image.SCALE_SMOOTH);
            ImageIcon scaledLogo = new ImageIcon(scaledImage);
            JLabel logoLabel = new JLabel(scaledLogo, JLabel.CENTER);
            add(logoLabel, BorderLayout.CENTER);

            Border etched = BorderFactory.createEtchedBorder();
            Border titled = BorderFactory.createTitledBorder(etched, "TRI - SWIM, BIKE, RUN");

            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            gridPanel = new JPanel(new GridLayout(0, 2));
            
            submit = new JButton("Submit Profile Info");
            gridPanel.add(submit);
            add = new JButton("Add Training Session");
            gridPanel.add(add);
            analyze = new JButton("Analyze Training");
            gridPanel.add(analyze);
            importCSV = new JButton("Upload CSV");
            gridPanel.add(importCSV);

            add(gridPanel, BorderLayout.SOUTH);
            gridPanel.setBorder(titled);

            eventTypeField = new JTextField();
            distanceField = new JTextField();
            timeField = new JTextField();
            speedField = new JTextField();
        }

        private void showTriathleteProfile() {

            JFrame frame = new JFrame("Triathlete Profile");

            
            Border etched3 = BorderFactory.createEtchedBorder();
            Border title3 = BorderFactory.createTitledBorder(etched3, "Triathlete's Development Info");

            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setSize(300, 300);
            frame.setResizable(false);

            JPanel triPanel = new JPanel();
            nameField = new JTextField(30);
            ageField = new JTextField(30);
            weightField = new JTextField(30);
            heightField = new JTextField(30);

            triPanel.add(new JLabel("Name:"));
            triPanel.add(nameField);
            triPanel.add(new JLabel("Age:"));
            triPanel.add(ageField);
            triPanel.add(new JLabel("Weight:"));
            triPanel.add(weightField);
            triPanel.add(new JLabel("Height:"));
            triPanel.add(heightField);

            triPanel.setBorder(title3);

            submit = new JButton("Submit Profile Info");
            gridPanel.add(submit);

            JButton saveTriInfo = new JButton("Save");
            saveTriInfo.addActionListener(this::saveTriathleteInfo);
            triPanel.add(saveTriInfo);

            frame.add(triPanel);
            frame.setVisible(true);
        }

        private void saveTriathleteInfo(ActionEvent e) {
            
            try {

                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                double weight = Double.parseDouble(weightField.getText());
                double height = Double.parseDouble(heightField.getText());

                triathlete.setName(name);
                triathlete.setAge(age);
                triathlete.setWeight(weight);
                triathlete.setHeight(height);

                JOptionPane.showMessageDialog(this, "Triathlete information saved.");

                nameField.setText("");
                ageField.setText("");
                weightField.setText("");
                heightField.setText("");

            } catch (NumberFormatException nfe) {

                JOptionPane.showMessageDialog(this, "Invalid entry. Please enter correct information.");
            }
        }

        private void showTrainingInput() {

            JFrame frame = new JFrame("Training Session Input");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setSize(400, 300);
            frame.setResizable(false);

            Border etched2 = BorderFactory.createEtchedBorder();
            Border title2 = BorderFactory.createTitledBorder(etched2, "Training Session's");

            JPanel panel = new JPanel(new GridLayout(0, 2));


            panel.add(new JLabel("Event Type (swim/bike/run):"));
            panel.add(eventTypeField);
            panel.add(new JLabel("Distance:"));
            panel.add(distanceField);
            panel.add(new JLabel("Time (minutes):"));
            panel.add(timeField);
            panel.add(new JLabel("Speed (km/h):"));
            panel.add(speedField);

            panel.setBorder(title2);

            JButton saveTraining = new JButton("Save");
            saveTraining.addActionListener(this::saveTrainingSession);
            panel.add(saveTraining);

            frame.add(panel);
            frame.setVisible(true);
        }

        private void saveTrainingSession(ActionEvent e) {
            try {

                String eventType = eventTypeField.getText();
                double distance = Double.parseDouble(distanceField.getText());
                double time = Double.parseDouble(timeField.getText());
                double speed = Double.parseDouble(speedField.getText());

                TrainingSession session = new TrainingSession(eventType, distance, time, speed);
                
                if (sessionCount < sessions.length) {

                    sessions[sessionCount++] = session;
                    triathlete.addTrainingSession(session);
                JOptionPane.showMessageDialog(this, "Training session has been added.");
                } else {
                    
                    JOptionPane.showMessageDialog(this, "Maximum number of sessions has been reached.");
                }
                
                eventTypeField.setText("");
                distanceField.setText("");
                timeField.setText("");
                speedField.setText("");

            } catch (NumberFormatException nfe) {

                JOptionPane.showMessageDialog(this, "Invalid entry. Please enter correct information.");
            }
        }

        private void importCSVFile(File file) {

            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

                String line;
                int lineNumber = 0;

                while ((line = reader.readLine()) != null) {

                    lineNumber++;

                    if (lineNumber == 1) {

                        continue;
                    }

                    String[] values = line.split(",");

                    if (values.length != 4) {

                        JOptionPane.showMessageDialog(this, "Invalid CSV format at line " + lineNumber);

                        return;
                    }

                    String eventType = values[0].trim();
                    double distance = Double.parseDouble(values[1].trim());
                    double time = Double.parseDouble(values[2].trim());
                    double speed = Double.parseDouble(values[3].trim());

                    TrainingSession session = new TrainingSession(eventType, distance, time, speed);
                    triathlete.addTrainingSession(session);

                    if (sessionCount < sessions.length) {

                        sessions[sessionCount++] = session;
                    
                    } else {

                        JOptionPane.showMessageDialog(this, "Maximum number of sessions reached.");
                    
                        break;
                    }
                }

                JOptionPane.showMessageDialog(this, "CSV imported successfully.");
            
            } catch (IOException ioe) {

                JOptionPane.showMessageDialog(this, "Error reading CSV file: " + ioe.getMessage());
            
            } catch (NumberFormatException nfe) {

                JOptionPane.showMessageDialog(this, "Invalid number format in CSV file. ");
            }

        }

        private void addListeners() {

            submit.addActionListener(this);
            add.addActionListener(this);
            analyze.addActionListener(this);
            importCSV.addActionListener(this);
        }

        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == submit) {
                
                    
                showTriathleteProfile();

            }else if (ae.getSource() == add) {

                showTrainingInput();

            } else if (ae.getSource() == analyze) {

                if (sessionCount > 0) {

                    String analyzeResult = trainingAnalysis.predictRaceOutcome(sessions, triathlete);
                    JOptionPane.showMessageDialog(this, analyzeResult);
                } else {

                    JOptionPane.showMessageDialog(this, "No training sessions available to perform analysis." );
                }
            } else if (ae.getSource() == importCSV) {

                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Select CSV File");
                fileChooser.setFileFilter(new FileNameExtensionFilter("CSV Files", "csv"));

                int result = fileChooser.showOpenDialog(this);
                if (result == JFileChooser.APPROVE_OPTION) {

                    File selectedFile = fileChooser.getSelectedFile();
                    importCSVFile(selectedFile);
                }
            }
        }
    }
}