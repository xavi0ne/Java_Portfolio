class TrainingSession {

    private String eventType;
    private double distance;
    private double time;
    private double speed;

    public TrainingSession(String eventType, double distance, double time, double speed) {

        if (distance < 0 || time < 0) {

            throw new IllegalArgumentException("Distance and/or time cannot be a negative or zero value.");
        }
        this.eventType = eventType;
        this.distance = distance;
        this.time = time;
        this.speed = calculateSpeed();
    }

    public double getTime() {

        return time;
    }

    public String getEventType() {

        return eventType;
    }

    public double getDistance() {

        return distance;
    }

    public double getSpeed() {

        return speed;
    }

    private double calculateSpeed() {

        return (time > 0) ? (distance / time) * 60 : 0;     //converts time for speed from min to hours
    }                                                       // in km/hr.
}