/**
 * 
 * @author: Xavier Torres
 * 
 * @version: last updated on 10_29_24
 * 
 * @credit:  Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              pg. 499-502.
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


/**
 * TrafficLight class creates a window frame that simulates a traffic light
 * with the green, yellow, and red lights. It initiates by calling the 'buildFrame()'
 * method to perform the frame specifications and utilizes another class which extends
 * JPanel to create and paint the Ovals used for the lights. 
 */
public class TrafficLight {

    private static JFrame jf;
    private static MyCircles c;
    private static JButton circleClick;
  

    public static void main(String [] args) {
        
        buildFrame(jf, c, circleClick);

    }

/*
 * the 'buildFrame()' method takes the parameters passed by main and
 * performs the build of JFrame and MyCircle objects. It also sets the
 * specifications for the frame to include ensuring it is visible, and 
 * closing program when user clicks the 'x' on window. The layout manager
 * used is BorderLayout and the Circles are set to center of frame. 
 */
    public static void buildFrame(JFrame jf, MyCircles c, JButton circleClick) {

        jf = new JFrame("Traffic Light");
        c = new MyCircles();
        circleClick = new JButton();
        jf.setSize(200, 620);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.add(c, BorderLayout.CENTER);
    }
}

/**
 * the MyCircles class is a subclass of JPanel, used as a dedicated drawing 
 * area to perform the draw and paint of the circles. 
 */
class MyCircles extends JPanel {

/**
 * the 'paintComponent()' method performs the operations
 * to draw and paint the circles, and to align them centered 
 * on the frame. The Graphics object is used for this and 
 * obtained via inheritence from JPanel class. 
 */
        public void paintComponent(Graphics g) {

            super.paintComponent(g);

            int width = getWidth();
            int height = getHeight();
            int diameter = Math.min(width, height /3) - 10;     //to ensure circles are suitable fit for frame vertically.
            int x = (width - diameter) / 2;         //to ensure each circle centers on frame horizontally.     

            g.setColor(Color.RED);          
            g.fillOval(x, 10, diameter, diameter);          //fillOval draws the circle and fills with the set color. 

            g.setColor(Color.YELLOW);
            g.fillOval(x, 10 + diameter + 10, diameter, diameter);

            g.setColor(Color.GREEN);
            g.fillOval(x, 10 + 2 * (diameter + 10), diameter, diameter);
        }
}