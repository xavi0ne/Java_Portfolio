/**
*@author: Xavier Torres
*
*@version: last updated 10_31_24
*
*@credit: Core Java: Fundamentals, Vol. 1
*              by: Cay Horstmann
*              Ch 11, section 11.2.1 & 11.2.3  
**/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 *the FifteenPuzzle class performs a program that presents a 15-puzzle to 
 *a user. The tiles are presented in order with a shuffle button on the bottom
 *to rearrange the tiles using the Random class. The program starts with 'main()'
 instantiating an instance of PuzzleFrame class that extends JFrame.
 */
public class FifteenPuzzle {

    private static final String TITLE = "FifteenPuzzle";

    public static void main(String [] args) {

        PuzzleFrame myFrame = new PuzzleFrame(TITLE);

        myFrame.setVisible(true);
    }
/**
 * the PuzzleFrame is an inner subclass of JFrame which leverages the ActionListener
 * interface to handle the layout and plumbing required to facilitate the logic. It uses
 * various helper methods to assist in performing the random shuffle and enabling the user
 * to make legal tile moves. 
 */
    static class PuzzleFrame extends JFrame implements ActionListener {

        private static final int WIDTH = 400, HEIGHT = 400;
        private final Random random = new Random();
        private JButton[] tiles;
        private JButton shuffle, exit;
        private int[] numbers;
        private JPanel gridPanel;
        private JPanel shufflePanel;
        

        public PuzzleFrame() {

        }
        public PuzzleFrame(String title) {

            layoutComponents(title);
            addListeners();
        }
/**
 * the 'layoutComponents()' is a method from the JFrame class that builds on the layout
 * for the frame to include its size, its visibility to user, and the specified layout manager
 * that will be used for the widgets.
 * */        
        private void layoutComponents(String title) {

            this.setTitle(title);

            setSize(WIDTH, HEIGHT);
            setLayout(new BorderLayout());
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            gridPanel = new JPanel(new GridLayout(4, 4));       //layout manager used is Gridlayout to arrange tiles
            tiles = new JButton[16];                            // in 2-dimensional grid of equal size.
            numbers = new int[16];
            
            shufflePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));         //Flowlayout manager is used specifically to arrange
            shuffle = new JButton("Shuffle");                                   //the 'shuffle' and 'exit' buttons to the left.
            shufflePanel.add(shuffle);
            exit = new JButton("Exit");
            shufflePanel.add(exit);

            add(shufflePanel, BorderLayout.SOUTH);
            add(gridPanel, BorderLayout.CENTER);

            for (int i = 0; i < numbers.length; i++) {          //for loops used to add the numbers to the tiles  
                numbers[i] = i + 1;                             // and add the tiles to the JPanel gridLayout.
            }
            numbers[15] = 0;

            for (int i= 0; i < tiles.length; i++) {
                tiles[i] = new JButton();
                if (numbers[i] !=0) {

                    tiles[i].setText(String.valueOf(numbers[i]));
                }
                gridPanel.add(tiles[i]);     
            }
        }
/**
 * the 'moveTile()' method performs the operations to ensure the user
 * is enabled to make legal tile moves for the tiles next to empty space.
 * Once the tiles are arranged to the original order, a message is prompted
 * to the user. The method leverages helper methods to assist with legal move
 * operations, and swap operations.  
 */
        private void moveTile(JButton tile) {
            int index = -1;
            for (int i = 0; i < tiles.length; i++) {

                if(tiles[i] == tile) {
                    
                    index = i;
                    break;
                }
            }

            int emptyTile = findTile();
            if (legalMove(index, emptyTile)) {

                swap(index, emptyTile);
            }

            if (solved()) {

                JOptionPane.showMessageDialog(this, "Congratulations, you have solved the FifteenPuzzle.");
            }
        }
/**
 * the 'swap()' method performs a swap for two tiles on the grid. It switches the text
 * displayed on the tiles array and updates the numbers array to reflect the new slots.
 */
        private void swap(int tile1, int tile2) {

            String getText = tiles[tile1].getText();
            tiles[tile1].setText(tiles[tile2].getText());
            tiles[tile2].setText(getText);
            numbers[tile2] = numbers[tile1];
            numbers[tile1] = 0;
        }
/**
 * the 'legalMove()' method calculates the row and column of both tile positions and 
 * ensures they are adjacent. It also ensures any moves not legal are not done. This 
 * is done using the Math class to perform calculations. 
 */
        private boolean legalMove(int tile1, int tile2) {

            int row1 = tile1 / 4;
            int column1 = tile1 % 4;
            int row2 = tile2 / 4;
            int column2 = tile2 % 4;

            return (Math.abs(row1 - row2) == 1 && column1 == column2) || (Math.abs(column1 - column2) == 1
                && row1 == row2);
        }
/**
 * the 'findTile()' method performs a for loop to search for the empty tile
 * which is identified by the '0' value, and returns a '-1' when not found. 
 */
        private int findTile() {

            for (int i = 0; i < numbers.length; i++) {

                if (numbers[i] == 0) {

                    return i;
                }
            }
            return -1;
        }
/**
 * the 'addListener()' method is provided by the ActionListener class
 * implemented, and performs a loop through each button of the tile array
 * adding the ActionListener to the current class so the 'actionPerformed()'
 * method can handle the button events. It then adds listeners to shuffle and
 * exit buttons to handle action events for them. 
 */
        private void addListeners() {

            for (JButton tile : tiles) {

                tile.addActionListener(this);
            }
            shuffle.addActionListener(this);
            exit.addActionListener(this);

        }
/**
 * the 'actionPerformed()' is a method provided by the ActionListener
 * class implemented, and defines the action events for the shuffle of 
 * the tiles, the movement of the tiles, and when the exit button is 
 * clicked by the user to close the program. 
 */
        public void actionPerformed(ActionEvent ae) {

            if (ae.getSource() == shuffle) {

                shuffleGame();
            } else {

                moveTile((JButton) ae.getSource());
            }
            if (ae.getSource() == exit) {

                System.exit(0);
            }
        }
/**
 * the 'shuffleGame()' method performs the shuffling of the tiles by performing
 * the random moves using the object instance of the Random class. the shuffling 
 * is done using a for loop which repeats 100 times to mix up the puzzle. 
 */
        private void shuffleGame() {

            for (int i = 0; i < 100; i++) {

                int empty = findTile();
                int[] adjacentMove = getAdjacentMove(empty);
                int swap = adjacentMove[random.nextInt(adjacentMove.length)];
                swap(swap, empty);
            }
        }
/**
 * the 'getAdjacentMove()' performs a search for the tiles that are adjacent to a 
 * given tile at index. Each index is then added to an array, which is then
 * returned. 
 */
        private int[] getAdjacentMove(int index) {

            int[] adjacent = new int[4];
            int count = 0;
            if (index >= 4) {

                adjacent[count++] = index - 4;
            }
            if (index < 12) {
                
                adjacent[count++] = index + 4;
            }
            if (index % 4 != 0) {
                
                adjacent[count++] = index - 1;
            }
            if (index % 4 != 3) {

                adjacent[count++] = index + 1;
            }
            int[] result = new int[count];
            System.arraycopy(adjacent, 0, result, 0, count);
            return result;
        }
/**
 * the 'solved()' method performs operations based on looping to check if the
 * 15-puzzle is solved by validating the order of the tiles, returning a boolean
 * value, whether false if not yet solved or true if it has been solved.  
 */
        private boolean solved() {

            for (int i = 0; i < numbers.length - 1; i++) {

                if (numbers[i] != i + 1) {

                    return false;
                }
            }
            return true;
        }
    }
}