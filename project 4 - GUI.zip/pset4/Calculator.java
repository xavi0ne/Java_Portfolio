/**
**@author: Xavier Torres
*
*@version: last updated 11_10_24
*
*@credit: Core Java: Fundamentals, Vol. 1
*              by: Cay Horstmann
*              Ch 11, section 11.2.1 & 11.2.3
*
*completed extra credit #7, and attempted #4. 
**/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * the Calculator class is a program that performs a graphical user
 * interface (GUI) of a Calculator, enabling the user to click on
 * a key and perform calculations. The class is based on the Model-
 * View-Controller (MVC) concept, where the Calculator is the View 
 * and the ActionListener called within Calculator is the Controller.
 * The Model is the CalcBackend.java class and performs the heavy 
 * lifting of arithmetic operations in the background. The program 
 * starts with 'main()' instantiating an instance of CalFrame class 
 * that extends JFrame and implements ActionListener.
 */
public class Calculator {

    private static final String TITLE = "Calculator";

    public static void main(String[] args){

        CalFrame calFrame = new CalFrame(TITLE);

        calFrame.setVisible(true);
    }
/**
 * the CalFrame class is an inner subclass of JFrame which uses the 
 * ActionListener interface to perform the layout and plumbing necessary
 * to perform the logic. It uses various methods to perform the component
 * layout and build of the GUI as well as performing the listening for events
 * through ActionListener. 
 * 
 */
    static class CalFrame extends JFrame implements ActionListener {

        private static final int WIDTH = 240, HEIGHT = 200;
       
        private JButton[] keyButtons;
        private JPanel gridPanel;
        private JTextField calDisplay;
        private CalcBackend calcBackend;

        public CalFrame() {

        }
        public CalFrame(String title) {

            calcBackend = new CalcBackend();
            layoutComponents(title);
            addListeners();
        }
/**
 * the 'layoutComponents()' is a method from the JFrame class that builds on the layout
 * for the frame to include its size, its visibility to user, and the specified layout manager
 * that will be used for the widgets.
 * @param title
 */
        private void layoutComponents(String title) {

            this.setTitle(title);

            setSize(WIDTH, HEIGHT);
            setLayout(new BorderLayout());
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            calDisplay = new JTextField("0.0");
            calDisplay.setHorizontalAlignment(JTextField.RIGHT);
            calDisplay.setFont(new Font("Arial", Font.BOLD, 24));
            calDisplay.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            add(calDisplay, BorderLayout.NORTH);

            gridPanel = new JPanel(new GridBagLayout());       //layout manager used is GridBagLayout to arrange tiles      
            add(gridPanel, BorderLayout.CENTER);               //suitable for a Calculator shape.
            String[] keys = {
                "7", "8", "9", "\u00F7", "4", "5", "6", "\u00D7", "1", "2", "3", 
                "-", "0", ".", "=", "+", "C", "\u221A", "(", ")"
            };

            keyButtons = new JButton[keys.length];
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.HORIZONTAL;

            for (int i = 0; i < keys.length; i++) {          //for loops used to add the numbers to the keys.

                keyButtons[i] = new JButton(keys[i]);
                keyButtons[i].setFocusPainted(false);

                int row = i / 4;
                int col = i % 4;

                gbc.gridx = col;
                gbc.gridy = row;

                gbc.gridwidth = 1;
                gbc.gridwidth = 1;
            
                gridPanel.add(keyButtons[i], gbc);
            }
        }
/**
 * the 'addListener()' method is provided by the ActionListener class
 * implemented, and performs a loop through each button of the keyButtons array
 * adding the ActionListener to the current class so the 'actionPerformed()'
 * method can handle the button events. It then adds listeners to keyButton to 
 * handle action events for them. 
 */
        private void addListeners() {

            for(JButton keyButton : keyButtons) {

                if (keyButton != null) {

                    keyButton.addActionListener(this);
                }
            }
        }

/**
 * the 'actionPerformed()' is a method provided by the ActionListener
 * class implemented, and defines the action events for the keys
 * clicked by the user. It calls the public methods '.feedChar()' and
 * '.getDisplayVal()' that belong to CalcBackend to pass the input over
 * and have the calculations performed on the backend to then be displayed
 * by the GUI. 
 */
        public void actionPerformed(ActionEvent ae) {
            
            String order = ae.getActionCommand();
            calcBackend.feedChar(order.charAt(0));
            calDisplay.setText(calcBackend.getDisplayVal());
        }
    }
}