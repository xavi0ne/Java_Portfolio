/**@author: Xavier Torres
*
*@version: last updated 11_9_24
*
*@credit: Core Java: Fundamentals, Vol. 1
*              by: Cay Horstmann
*              Ch 11, section 11.7
*/

import javax.swing.JOptionPane;

/**
 * 
 * The Age class is a simple program that prompts the user
 * asking for age using the 'showInputDialog()' method from 
 * the JOptions class. The user's response is stored in the 
 * 'askAge' variable of type String. A conditional
 * expression is used to display responses, if user inputs
 * a value 40 or less, it will deliver message using 'showMessageDialog()'
 * on how young user is; should the input be greater than 40, the 
 * alternate message will execute humoring how old user is. 
 */
public class Age {

    public static void main (String [] args) {

        String askAge;
        
        askAge = JOptionPane.showInputDialog("What's your age, cowboy?");

        int age = Integer.parseInt(askAge);         //The variable is then converted into an int value using 'parseInt()' 
                                                    //from the Integer class and stored in age variable.
        if (age <= 40) {

            JOptionPane.showMessageDialog(null, "You are young!");

        } else {

            JOptionPane.showMessageDialog(null, "I knew it!, the white hairs shows your getting old!");
        }
    }
}