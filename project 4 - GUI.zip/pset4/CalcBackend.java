/*
*@author: Xavier Torres
*
*@version: last updated 11_4_24
*
*@credit: Core Java: Fundamentals, Vol. 1
*              by: Cay Horstmann
*              Ch 11, section 11.1
*
*The following characters are included and passed to 'feedChar()':
* 
*          Operation        char passed to feedChar()
         ---------        -------------------------
         Clear            'C',
         Square Root      '\u221A',
         Multiplication   '\u00D7',
         Division         '\u00F7',
         Addition         '+',
         Subtraction      '-';
*
**/
/**
 * 
 * the ClacBackend class performs the calculation by 
 * keeping track of what user inputs within the Calculator
 * class and what should be displayed on the screen, updating
 * based on key input. This type of program is based on Model-View-
 * Controller (MVC) pattern. The Calculator.java is the View, and the
 * CaclBackend.java is the Model. 
 */

 public class CalcBackend {

    enum CurrentState {

        FIRST_OPERAND, CONSTRUCT_FIRST, SECOND_OPERAND, CONSTRUCT_SECOND,
            CONSTRUCT_DECIMAL
    }
    
    double displayVal;
    private String displayString;
    private Double operand1;
    private CurrentState currentState;
    private char operator;

/**
 * the Constructor used to initialize the calculator's state 
 * with default values. 
 */
    public CalcBackend() {

        defaultReset();
        
    }
/**
 * the 'defaultReset()' ensures the state is cleared and reset to 
 * default values. This helper method is used to reduce redundant 
 * coding within the program on Constructor and switch operations. 
 */
    private void defaultReset() {

        this.displayVal = 0.0;
        this.displayString = "0";
        this.operand1 = null;
        this.operator = '\0';
        this.currentState = CurrentState.FIRST_OPERAND;

    }
/**
 * the 'feedChar()' method is the main entry point for managing user
 * input and performs the processing of the input character using switch
 * operations to route to respective helper method. Manages the various
 * characters described above to pass and perform operations to include
 * clearing the display values, calculating square root, calculating binary
 * ops such as addition, subtraction, multiplication, and division, and 
 * appending decimal points.
 * @param c
 */
    public void feedChar(char c) {

        switch (c) {
            case 'C':
                defaultReset();
                break;
            case '\u221A':
                squareRootHandling();
                break;
            case '=':
                if (this.operator != '\0' && this.operand1 != null) {

                    calculate();
                    this.currentState = CurrentState.FIRST_OPERAND;                
                }
                break;
            case '+', '-', '\u00D7', '\u00F7':
                operatorHandling(c);
                break;
            case '.':
                decimalHandling();
                break;
            case '(', ')':
                parenthesisHandling(c);
                break;
            default:
                digitHandling(c);
                break;
        }
    }
/**
 * the 'squareRootHandling()' method performs square root
 * operations using the Math class and ensure it is displayed
 * on Calculator. To control error handling, the 'try-catch'
 * is used ensure 'NaN' when improper input is entered. 
 */
    private void squareRootHandling() {

        try {
            this.displayVal = Math.sqrt(displayVal);
            this.displayString = formatDisplay(displayVal);
            this.currentState = CurrentState.FIRST_OPERAND;
        } catch (Exception e) {
            this.displayVal = Double.NaN;
            this.displayString = "Error";
        }
    }
/*
 * the 'parenthesisHandling()' is an attempt on the extra 
 * credit with intent to display the '(' and ')' values when
 * inputted within the displayString.
 */
    private void parenthesisHandling(char c) {

            displayString += c;
    }
/**
 * the 'getDisplayVal()' method performs the displayed values
 * after is called by GUI and 'feedChar()' to get the String
 * the GUI should display.
 */
    public String getDisplayVal() {

        String displayString = "" + this.displayVal;

        return displayString;
    }
/**
 * the 'operatorHandling()' method performs the preparation for
 * operand1 by setting the current operator when an arithmetic 
 * operator is entered by user. The values are passed by 'feedChar()'.
 * Conditional expression is used to ensure the current State is displayed.
 */
    private void operatorHandling(char c) {
        if (currentState == CurrentState.FIRST_OPERAND || currentState == 
            CurrentState.CONSTRUCT_FIRST) {

            operator = c;
            operand1 = displayVal;
            currentState = CurrentState.SECOND_OPERAND;
            displayString = "";
        } else if (currentState == CurrentState.CONSTRUCT_SECOND) {

            calculate();
            operator = c;
            operand1 = displayVal;
            currentState = CurrentState.SECOND_OPERAND;
            displayString = "";
        }  
    }
/**
 * the 'digitHandling()' performs the process of the input passed 
 * by 'feedChar()' and updates the displayString and displayVal as 
 * required. Conditional expression is used to ensure the current 
 * State is displayed.
 */
    private void digitHandling(char c) {

        if (currentState == CurrentState.FIRST_OPERAND || currentState == CurrentState.CONSTRUCT_FIRST) {
            
            if(displayString.equals("0")) {

                displayString = "";
            }
            displayString += c;
            currentState = CurrentState.CONSTRUCT_FIRST;
        } else if (currentState == CurrentState.CONSTRUCT_DECIMAL || currentState == CurrentState.SECOND_OPERAND) {

            displayString += c;
            currentState = CurrentState.CONSTRUCT_SECOND;

        } 
        displayVal = displayStringParse();    
    }
/**
 * the 'displayStringParse()' method performs error handling by returning
 * NaN and ensures that the value from displayString is converted to a 
 * double.
 * 
 */
    private double displayStringParse() {
        
        try {
            return Double.parseDouble(displayString);
        } catch (NumberFormatException e) {

            return Double.NaN;
        }
    }
/**
 * the 'decimalHandling()' method performs the management of the 
 * decimal point when it is added to the current input and ensures
 * only one can be displayed. Conditional expression is used to ensure 
 * the current State is displayed.
 */
    private void decimalHandling() {
        
        if (!displayString.contains(".")) {
            
            if(currentState == CurrentState.SECOND_OPERAND) {

                displayString = "0";
                currentState = CurrentState.CONSTRUCT_DECIMAL;
                
            } else if (currentState == CurrentState.FIRST_OPERAND || currentState == CurrentState.CONSTRUCT_FIRST) {

                if (displayString.equals("0")) {

                    displayString = "";
                }
                currentState = CurrentState.CONSTRUCT_DECIMAL;
            }
            displayString += ".";
        }
        displayVal = displayStringParse();
    }
/**
 * the 'calculate()' method performs the basic arithmetic
 * operations to include addition, subtraction, multiplication,
 * and division. The operation involves leveraging switch based
 * on the input value passed the operator variable. It performs
 * error handling on attempts to divide by zero using ternery 
 * operator. 
 */
    private void calculate() {

        switch (operator) {
            case '+':
                displayVal = operand1 + displayVal;
                break;
            case '-':
                displayVal = operand1 - displayVal;
                break;  
            case '\u00D7':
                displayVal = operand1 * displayVal;
                break;
            case '\u00F7':
                displayVal = (displayVal == 0) ? Double.NaN : operand1 / displayVal;
                break;
        }
        displayString = formatDisplay(displayVal);
        operand1 = null;  
    }
/**
 * the 'formatDisplay()' performs the clean display for the results,
 * ensuring the string is clean and without trailing values that
 * are not needed to limit display length.
 */
    private String formatDisplay(double value) {

        String displayResult = "" + value;
        if (displayResult.endsWith(".0")) {

            displayResult = displayResult.substring(0, displayResult.length() - 2);
        }

        if (displayResult.length() > 12) {

            displayResult = displayResult.substring(0, 12);
        }
        return displayResult;
    }
}