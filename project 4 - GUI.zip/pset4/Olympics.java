/*
*@author: Xavier Torres
*
*@version: last updated 11_10_24
*
*@credit: Core Java: Fundamentals, Vol. 1
*              by: Cay Horstmann
*              Chapter 11.
*/

import javax.swing.*;
import java.awt.*;


/*
 * the Olympics class performs the inner classes and methods designed 
 * to display the Olympics Rings outlined in their respective colors. 
 * The main method instantiates an instance of a class that extends 
 * JFrame. 
 */
public class Olympics {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Olympics");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 350);
        

        OlympicPanel olympicPanel = new OlympicPanel();
        frame.add(olympicPanel);
        frame.setVisible(true);
    }
/**
 * the OlympicPanel class is an inner subclass that
 * inherits the methods required to perform a canvas 
 * and paintbrush operation and draw the Olympic rings 
 * with their respective colors. As a best approach
 * using swing to create the dedicated drawing area as a
 * subclass of JPanel. 
 */
    static class OlympicPanel extends JPanel {

/*
 * the 'paintComponent()' method is used to create the
 * canvas and paintbrush, enabling the olympic rings 
 * to be drawn. The BasicStroke() sets the thickness
 * of the rings. The method also sets the colors for
 * each of the rings. 
 */
        public void paintComponent(Graphics g) {       

            super.paintComponent(g);

            Graphics2D graphics2d = (Graphics2D) g;
            graphics2d.setStroke(new BasicStroke(8));

            drawRing(graphics2d, Color.BLUE, 50, 50);
            drawRing(graphics2d, Color.BLACK, 150, 50);
            drawRing(graphics2d, Color.RED, 250, 50);
            drawRing(graphics2d, Color.YELLOW, 100, 100);
            drawRing(graphics2d, Color.GREEN, 200, 100);

        }
/*
 * the 'drawRing()' method takes the Graphics2D object with the color
 * parameters as well as the x and y, and performs the operations to set the 
 * color and draw the Olympic rings. 
 */
        private void drawRing(Graphics2D graphics2d, Color color, int x, int y) {

            graphics2d.setColor(color);
            graphics2d.drawOval(x, y, 100, 100);
        }
    }
}