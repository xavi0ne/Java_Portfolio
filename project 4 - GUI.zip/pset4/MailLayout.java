/**
 * 
 * @author: Xavier Torres
 * @version: last updated 10_27_24
 * @credit: Core Java: Fundamentals, Vol. 1
 *              by: Cay Horstmann
 *              Ch 10, section 10.2.1 & 10.4.1 
 * 
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;


/**
 * The MailLayout class performs a simulated mail program that presents
 * a window to compose a new email message. When the user clicks on send, 
 * the content from the window is outputted in a file within the directory
 * by name of 'outbox.txt'. The title changes when user inputs text within
 * the JTextField 'subject', and remains as "New Message" when subject is 
 * cleared or empty.
 * */
public class MailLayout {

    public static void main(String [] args) {

        new MailLayout().initiate();        //constructor created which calls on 'initiate()' method
                                            //to ensure the method and inner classes perform the heavy
    }                                       //lifting and not main.
    private void initiate() {

        new MailEventFrame();
    }
/**
 * 
 * MailEventFrame inner class is a subclass of JFrame and provides all the 
 * specifications to develop the window for MailLayout program. The
 * components include JTextFields, JTextArea, JPanels, JBtton and a JComboBox.
 * The JPanels are nested using layout managers BorderLayout and FlowLayout to 
 * organize components. 
 */
    public class MailEventFrame extends JFrame {

        private static final String TITLE = "New Message";
        private static final int WIDTH = 500, HEIGHT = 300;
        private static JTextField[] tf = new JTextField[4];
        private static JTextArea message;
        private JButton send;
        private static JComboBox<String> from;

        public MailEventFrame() {

            setTitle(TITLE);
            setSize(WIDTH, HEIGHT);
            setLayout(new BorderLayout());
            setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setVisible (true);

            JPanel inputPanel = new JPanel();
            inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
    
            send = new JButton("Send");
            JPanel sendPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            sendPanel.add(send);
            send.addActionListener(new SendAction());
            
            JPanel fromPanel = new JPanel(new BorderLayout());
            fromPanel.add(new JLabel("From:"), BorderLayout.WEST);
            from = new JComboBox<>(new String[] {"xtorres1@live.com", "xt@live.com", "xt1@live.com"});
            fromPanel.add(from, BorderLayout.CENTER);
    
            message = new JTextArea();
            add(new JScrollPane(message), BorderLayout.CENTER);
    
            String[] fields = {"To:", "Cc:", "Bcc:", "Subject:"};
            for (int i=0; i < fields.length; i++) {
                JPanel panel = new JPanel(new BorderLayout());
                panel.add(new JLabel(fields[i]), BorderLayout.WEST);
                tf[i] = new JTextField(30);
                panel.add(tf[i], BorderLayout.CENTER);
                inputPanel.add(panel);
            }
            tf[3].addActionListener(new SubjectAction());

            JPanel topPanel = new JPanel(new BorderLayout());
            topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
            topPanel.add(inputPanel, BorderLayout.NORTH);
            topPanel.add(fromPanel, BorderLayout.CENTER);
            topPanel.add(sendPanel, BorderLayout.SOUTH);
            add(topPanel, BorderLayout.NORTH);
        }

/**
 * the inner class SubjectAction leverages the ActionListener class interface
 * to listen and perform the actionEvent to enable the updates for the subject when the
 * user adds text and ensure the title is changed according to subject. When the
 * subject is cleared, the title of window is updated to "New Message".
 */
        class SubjectAction implements ActionListener {

            public void actionPerformed(ActionEvent e) {

                String subjectString = tf[3].getText().trim();
                if (subjectString.isEmpty()) {

                    setTitle(TITLE);
                } else {

                    setTitle(subjectString);
                }  
            }
        }

/**
 * The inner class SendAction leverages the ActionListener class interface
 * to listen and perform the ActionEvent by calling the 'actionSend()' method
 * which performs the heavy lifting for performing operations of simulating
 * the send of email message and creating the 'outbox.txt' file. 
 */
        class SendAction implements ActionListener {

            public void actionPerformed(ActionEvent e) {

                actionSend();
        
            }
/**
 * 
 * the 'actionSend()' method performs the operations to create a BufferedWriter and
 * FileWriter object to enable user to write to a file called 'outbox.txt' when inputting
 * text on the JTextArea. The file collects input from the JPanel components as well. Error
 * handling is controlled for IOExceptions using try-catch to inform user when message is sent or failed 
 * to send. 
 */
            private void actionSend() {

                try (BufferedWriter writeFile = new BufferedWriter(new FileWriter("outbox.txt"))) {
        
                    writeFile.write("To: " + tf[0].getText() + "\n");
                    writeFile.write("Cc: " + tf[1].getText() + "\n");
                    writeFile.write("Bcc: " + tf[2].getText() + "\n");
                    writeFile.write("From: " + from.getSelectedItem() + "\n");
                    writeFile.write("Subject: " + tf[3].getText() + "\n\n");
                    writeFile.write(message.getText());
        
                    JOptionPane.showMessageDialog(null, "Message has been sent");
        
                    for (JTextField field : tf) {

                        field.setText("");
                    }
                    message.setText("");
                    setTitle(TITLE);
                } catch (IOException e) {
        
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Message sent failed", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
}