import java.io.*;
import java.util.*;

/**
 * 
 * the CaesarCipher class performs operations to create secret messaging
 * using files by substituting each letter in the original plaintext file
 * by shifting the alphabet by a number value stored in the shift
 * variable. The main method begins the operations of prompting user for 
 * inputs by using a Scanner object. The printStream object is created to 
 * perform write operations and create the output file.
 * 
 *@author: Xavier Torres
 * 
 *@version: last updated on 10-18-24
 * 
 *@credit:  Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              pg. 935-939 & 952-956.
 */

public class CaesarCipher {

    public static void main (String[] args) {

        Scanner keyboard = new Scanner(System.in);

        while (true) {

            System.out.println("Welcome to CaesarCipher");
            System.out.print("Enter 1 to encipher, or 2 to decipher (-1 to exit):");
            int selection = keyboard.nextInt();
            if (selection == -1) break;
        

            System.out.print("What shift should I use?");
            int shift = keyboard.nextInt();
            keyboard.nextLine();

            System.out.print("What is the input file name? ");
            String inputFileName = keyboard.nextLine();     //using '.nextLine()' ensures the file is read past the current line.

            System.out.print("What is the output file name? ");
            String outputFileName = keyboard.nextLine();

            try {

                Scanner input = new Scanner(new File(inputFileName));
                PrintStream writeFile = new PrintStream(new FileOutputStream(outputFileName));      //printStream object used to perform file write
                                                                                                    // operations and output a new file based on users
                while (input.hasNextLine()) {                                                       // input. 

                    String writeLine = input.nextLine();
                    if (selection == 1) {

                        writeFile.println(caesarEncipher(writeLine, shift));
                    
                    } else {

                        writeFile.println(caesarDecipher(writeLine, shift));
                    }
                }
                input.close();
                writeFile.close();

                System.out.println("DONE!");
            }
            catch(FileNotFoundException fnf) {

                System.out.println("Input file cannot be found. Please try again. ");       // try-catch is used for the checked exception to ensure
            }                                                                                 // control handling should the input file not be found.
        }
        keyboard.close();
    }

/**
 * 
 * the 'caesarEncipher()' method takes the parameter values
 * passed from main and ensures the input file is processed using
 * the StringBuilder to control the letters and ignore the one's that
 * are not uppercase. The Character class is also used to check each
 * letter within a for loop and ensures base character is set using a 
 * ternery operator. the processed file is then appended and then returned
 * to be leveraged by the next method. 
 * 
 * @param input
 * @param shift
 * @return
 */
    public static String caesarEncipher (String input, int shift) {

        StringBuilder encrypt = new StringBuilder();
        for (char letter : input.toCharArray()) {

            if (Character.isLetter(letter)) {

                char base = Character.isLowerCase(letter) ? 'a' : 'A';
                letter = (char) (( letter - base + shift) % 26 + base);     //the alphabet shift is performed using expression to 
            }                                                               //do the legwork and encipher the file's input. 
            encrypt.append(letter);
        }
        return encrypt.toString();
    }


/**
 * 
 * the 'caesarDecipher()' performs decryption operations by taking the 
 * parameter values, to include the input file processed
 * by the 'caesarEncipher()' method, and the selected shift by the user. 
 * The method decrypts by reverting the previous shift to encrypt. 
 * 
 * @param input
 * @param shift
 * @return
 */
    public static String caesarDecipher (String input, int shift) {

        return caesarEncipher(input, 26 - shift);
    }
}