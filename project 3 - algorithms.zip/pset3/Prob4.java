/**
 * 
 *@author: Xavier Torres
 * 
 *@version: last updated on 10-14-24
 * 
 *@credit:  Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              pg. 935-939 & 952-956.
 * 
 * The Prob4 class performs operations to prompt a user to input two 
 * integers and performs an expression to divide them. Error handling
 * is controlled using a while loop to ensure valid input is 
 * received from user, and a try-catch with multiple catches
 * so that error messages are printed for arithmetic exceptions and 
 * inputmismatch exceptions. If such errors occur, the while loop 
 * ensures the user is given a message and allowed to retry until 
 * valid input is received. 
 */

import java.util.*;

public class Prob4 {

    public static void main(String[] args) {

        Scanner keyboard = new Scanner(System.in);
        int n1, n2;
        boolean validUserInput = false;

        while(!validUserInput) {
            
            try {

                System.out.print("Type an int: ");
                n1 = keyboard.nextInt();
                System.out.print("Now type another int: ");
                n2 = keyboard.nextInt();
                int r = n1 / n2;
                validUserInput = true;
            }
            catch(ArithmeticException ae) {

                System.err.printf("Error: cannot divide by zero.");
                keyboard.nextLine();

            }
            catch(InputMismatchException ime) {

                if (!keyboard.hasNextInt()) {

                    System.err.printf("Error: String values are not allowed. ");
                    keyboard.nextLine();
                }
            }
        }
    }
}