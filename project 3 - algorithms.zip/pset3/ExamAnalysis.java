/**
 * The ExamAnalysis class performs the reading from a File and prompts the user to input 
 * the correct exam answers as well as the file name. How this is accomplished is by using 
 * the Scanner class and the File class to create objects, and then perform 
 * several tasks within the four methods described below to provide a complete
 * listing of the students scores, and how they answered each question on the 
 * exam. 
 * 
 **@author: Xavier Torres
 * 
 *@version: last updated on 10-16-24
 * 
 *@credit:  Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              pg. 935-939
 */

import java.util.*;
import java.io.*;

public class ExamAnalysis {

    public static void main(String[] args ) {

        Scanner keyboard = new Scanner(System.in);
        String correctAnswers = userInput1(keyboard);

        ArrayList<String> studentAnswers = userInput2(keyboard);

        studentAnalysis(studentAnswers, correctAnswers);
        questionAnalysis(studentAnswers, correctAnswers);
  
    }
/**
 * 
 * The 'userInput1()' method performs by taking the keyboard param values 
 * passed from the main, which stores the Scanner object. The user is prompted
 * to input the correct answers to the exam questions. A while loop is used 
 * to control error handling in such case which the correctAnswers variable does
 * not contain the correct answers, and prompts the user to reenter when invalid 
 * until correct input is provided. correctAnswers variable is then returned to be
 * used in the 'studentAnalysis()' and 'questionAnalysis()' methods. 
 * 
 * @param keyboard
 * @return
 */
    private static String userInput1(Scanner keyboard) {

        System.out.println("I hope you are ready to begin... \n");

        System.out.print("Please type the correct answers to the exam questions,\r\n" +
                            "one right after the other: ");
        String correctAnswers = keyboard.nextLine();

        while (!correctAnswers.contains("ABCEDBACED")) {

            System.out.print("The answer key must only contain combinations of " +
                                "A, B, C, D, and E. ");

            System.out.print("Please type the correct answers to the exam questions,\r\n" +
                                "one right after the other: ");

            correctAnswers = keyboard.nextLine();
        }

        return correctAnswers;
    }


    /**
     * 
     * the 'userInput2()' method takes the keyboard param from main and prompts
     * the user to input the file name. It controls error handling with a while
     * loop in case the user inputs incorrect file name, ensuring the user is 
     * allowed to reenter the file name until it is correct. An ArrayList is created
     * and also a Scanner object. The ArrayList stores the Scanner object with the 
     * input from the user and uses a while loop to create the output from each student
     * and the exam info in a table format. The catch controls error handling for 
     * cases in which the file is not found. 
     * 
     * @param keyboard
     * @return
     */
    private static ArrayList<String> userInput2(Scanner keyboard) {

        System.out.print("What is the name of the file containing each student's\r\n" +
                                "responses to the 10 questions?");
        File fileName = new File (keyboard.nextLine());

        while (!fileName.canRead()) {

            System.out.println("File not found. Try again. ");
            System.out.print("What is the name of the file containing each student's\r\n" +
                                "responses to the 10 questions?");

            fileName = new File(keyboard.nextLine());
        }

        ArrayList<String> studentAnwsers = new ArrayList<>();

        try {

            Scanner examReader = new Scanner(fileName);
            
            int student = 1;
            while (examReader.hasNextLine() && student <= 9) {

                
                String examInfo = examReader.nextLine();
                System.out.println("Student #" + student + "'s responses: " + examInfo);
                studentAnwsers.add(examInfo);
                student++;
            }
            System.out.println("We have reached \"end of file!\"");
            examReader.close();
        }
        catch(FileNotFoundException fnf) {

            System.out.println("File cannot be found.");
        }
        return studentAnwsers;
    }

/**
 * 
 * The 'studentAnalysis()' method formats the input passed from the parameters, to include the ArrayList
 * 'studentAnwsers' and String 'correctAnwsers', and creates a table using nested while loop and outputs 
 * each student with their correct, incorrect, and blank responses.
 * 
 * @param studentAnwsers
 * @param correctAnswers
 */
    private static void studentAnalysis(ArrayList<String> studentAnwsers, String correctAnswers) {
        
        System.out.println();
        System.out.println("Thank you for the data on 9 students. Here's the analysis: ");
        System.out.println("Student #\t Correct\t Incorrect\t Blank");
        System.out.println("~~~~~~~~~\t ~~~~~~~\t ~~~~~~~~~\t ~~~~~");

        int student = 1;
        int index = 0;

        while (index < studentAnwsers.size()) {     //a nested while loop is done to ensure the input is handled 
                                                    // in a table format.
            String anwsers = studentAnwsers.get(index);
            int correct = 0, incorrect = 0, blank = 0;

            int i= 0;
            while (i < correctAnswers.length()) {

                if(i < anwsers.length()) {

                    char studentResponse = anwsers.charAt(i);

                    if (studentResponse == correctAnswers.charAt(i)) {

                        correct++;
                    } else if (studentResponse == ' ') {

                        blank++;
                    } else {

                        incorrect++;
                    }
                } else {

                    blank++;
                }
                i++;
            }
            System.out.printf("Student #%d\t\t%d\t\t%d\t\t%d\n", student++, correct, incorrect, blank);

            index++;
        }
    }
/**
 * The 'studentAnalysis()' method formats the input passed from the parameters, to include the ArrayList
 * 'studentAnwsers' and String 'correctAnwsers', and creates a table using nested for loop and outputs
 *  how the students answered each question on the exam.  
 * 
 * @param studentAnwsers
 * @param correctAnswers
 */
    private static void questionAnalysis (ArrayList<String> studentAnwsers, String correctAnswers) {

        System.out.println();
        System.out.println("QUESTION ANALYSIS\t (* marks the correct response)");
        System.out.println("~~~~~~~~~~~~~~~~~");

        int sum = studentAnwsers.size();
        int questionsTotal = correctAnswers.length();

        for (int i = 0; i < questionsTotal; i++) {

            int[] counts = new int[6];

            char correctAnswer = correctAnswers.charAt(i);

            for (String answers: studentAnwsers) {

                if (i < answers.length()) {

                    char response = answers.charAt(i);
                    int index = response - 'A';

                    if (index >= 0 && index <= 4) {

                        counts[index]++;
                    } else {

                        counts[5]++;
                    }
                } else {

                    counts[5]++;
                }
            }

            System.out.println("Question #" + (i + 1) + ":");
            System.out.println();
            System.out.printf("%s\t", (correctAnswer == 'A' ? "A*" : "A") + " ");        // ternery operator is used to conditionally express if 
            System.out.printf("%s\t", (correctAnswer == 'B' ? "B*" : "B") + " ");        // students selected answer is the target value, then
            System.out.printf("%s\t", (correctAnswer == 'C' ? "C*" : "C") + " ");        // add the wildcard to the value; if not, then leave as
            System.out.printf("%s\t", (correctAnswer == 'D' ? "D*" : "D") + " ");        // is and add a space at the end.
            System.out.printf("%s\t", (correctAnswer == 'E' ? "E*" : "E") + " ");
            System.out.println("Blank");

            System.out.printf("%d\t %d\t %d\t %d\t %d\t %d\n", counts[0], counts[1], counts[2], 
                counts[3], counts[4], counts[5]);

            System.out.printf("%.1f%%\t %.1f%%\t %.1f%%\t %.1f%%\t %.1f%%\t %.1f%%\n", 
                (counts[0] * 100.0 / sum), (counts[1] * 100.0 / sum), 
                (counts[2] * 100.0 / sum), (counts[3] * 100.0 / sum), 
                (counts[4] * 100.0 / sum), (counts[5] * 100.0 / sum));
            System.out.println();
        }   
    }
}