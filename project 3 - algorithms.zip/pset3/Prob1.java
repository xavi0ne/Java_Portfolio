/**
 * 
 * Prob1 is a class that uses main method to perform operations
 * to include prompting a user to input using a Scanner object.
 * It then uses '.split()' to split the input and add a space for 
 * each, and stores it in a variable of type String array. Then 
 * uses a for loop to reverse and prints its 
 * command line arguments.
 * 
 *@author: Xavier Torres
 * 
 *@version: last updated on 10-12-24
 * 
 *@credit:  Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              pg. 935-939
 */

import java.util.*;

public class Prob1 {

    public static void main(String[] args) {

        Scanner str = new Scanner(System.in);

        System.out.println("add input: ");

        String userInput = str.nextLine();

        String[] stmt = userInput.split("\\s+");

        System.out.println("The 5 command-line args are:\n ");
        for (int i = stmt.length - 1; i >= 0; i--) {

            System.out.println(stmt[i]);
        }

    }
}