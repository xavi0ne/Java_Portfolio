/**
 * The Enumeration class performs operations to print how many
 * days are in each of the 12 months for the year 2023 using the 
 * switch operator, with a 
 * special switch case for February to reflect the leap year.
 * 
 * @author Xavier Torres
 * @Version Last modified on 09_07_24
 * 
 * @credit: Building Java Programs, 
 *      by Stuart Reges and Marty Stenn, 
 *      pg. 2647-2649 and pg. 2654-2656.
 */



import java.util.*;

enum Months { JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, 
                OCT, NOV, DEC};

class Enumeration {

/**
 * The 'daysInMonth()' method performs a switch() operation using enumeration. The cases
 * were organized to reduce redundancy in code, by adding collectively the months ending
 * in 31 as well as 30. A special case is added for FEB, with a conditional expression 
 * evaluating the leap year to determine if the particular year result in the month
 * ending in 29 or 28. The optional default was added with an 'IllegalArgumentException'
 * to control error handling. The 'days' variable was created to store the days of the 
 * month for each case block of code. 
 */

    public static int daysInMonth (Months m, int year) {

        int days;

        switch (m) {        

            case JAN, MAR, MAY, JUL, AUG, OCT, DEC -> {     //bundled the months that have 31 days to reduce redundancy.
                days = 31;
            }     
            case APR, JUN, SEP, NOV -> {
                days = 30;
            }
            case FEB -> {
                if (year / 400 == 0 || (year / 4 == 0 && year / 100 !=0)) {     // expresion evenly divides year by 400 or
                    days = 29;                                                  // evenly divides year by 4 and evenly divides year by 100
                } else {
                    days = 28;
                }
            }
            default -> {
                throw new IllegalArgumentException("wrong month: " + m);        //added default for error handling.
            }
        }
        return days;
    }

    public static void main (String [] args) {

        for (Months m : Months.values()) {

            System.out.println (m + " 2023 has " + daysInMonth(m, 2023) +
                            " days!");
        }
    }
}