/**
 * 
 * The Binomial class uses the binomial coefficient approach in a recursive manner to 
 * develop Pascal's triangle using the Scanner class to obtain the user's input based 
 * on the amount of columns the program will execute. The main method then performs 
 * an iterative loop based on the user's input and makes a call to the 'c() method'.
 * 
 * @author Xavier Torres
 * @Version Last modified on 09_19_24
 * 
  @credit: Building Java Programs 5th Ed., 
 *      by Stuart Reges and Marty Stenn, 
 *      pg. 1791-1822.
 */

import java.util.Scanner; 

public class Binomial {

    public static void main(String[] args) {

        int inputColumn;

        Scanner userKeyboard = new Scanner(System.in);
        System.out.print("Enter amount of columns to build Pascals Triangle: ");

        inputColumn = userKeyboard.nextInt();

        for (int i = 0; i <= inputColumn; i++) {

            for (int j = 0; j <= i; j++) {

                    System.out.printf("%d", c(i, j));
                
            }
            System.out.println();
        }
    }

/**
 * The 'c()' method is a representation of a binomial coefficient which
 * performs a recursive approach. The 'inputColumn' and 'rows' variables
 * represent the number of ways to choose (rows) elements from a 
 * set of (inutColumn) elements. 
 */

    public static int c(int inputColumn, int rows) {

        if (rows == 0 || rows == inputColumn) {     //base case #1 to ensure 1 is returned based on conditional expression. 
            return 1;

        } else if (rows > inputColumn) {        //base case #2 to ensure 0 is returned based on conditional expression. 
            return 0;

        } else {
            return c(inputColumn -1, rows-1) + c(inputColumn - 1, rows);        //recursive case in which the recursive method
                                                                                //is called 2x's by first including the current 
        }                                                                       //element reducing both variables by one, followed by
    }                                                                           //concatenation of 'c()' where we reduce
}                                                                               //'inputColumn' by one but keep 'rows' the same.