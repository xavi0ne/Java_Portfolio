/**
 * 
 * The RecursiveSum class performs various calls to 
 * the recursive 'sumTo()' method with different actual
 * values from within the main method. The values are
 * then passed to the sumTo method header.
 * 
 * @author Xavier Torres
 * @Version Last modified on 09_10_24
 * 
 * @credit: Building Java Programs, 
 *      by Stuart Reges and Marty Stenn, 
 *      pg. 1778-1779, 651-652, and 637-639.
 */

public class RecursiveSum {

    public static void main(String [] args) {

        System.out.printf("sumTo(%d) = %.1f\n", 1, sumTo(1));       //using 'printf' to format string and specify output
        System.out.printf("sumTo(%d) = %.1f\n", 2, sumTo(2));       //to include the '%d' which indicates decimal integer
        System.out.printf("sumTo(%d) = %.1f\n", 3, sumTo(3));       //and '%.1f' which indicates double or floating point 
        System.out.printf("sumTo(%d) = %.1f\n", 4, sumTo(4));       //with only 1 digit output after the decimal
        System.out.printf("sumTo(%d) = %.1f\n", 0, sumTo(0));       //and '\n' is an escape with new line.
        System.out.printf("sumTo(%d) = %.1f\n", -1, sumTo(-1));
    }


 /**
 * The 'sumTo()' method performs recursion and takes
 * the formal integer parameter 'n', returns the sum
 * of the first 'n' reciprocal, ensures any zero values
 * return a double value type, and performs error
 * handling control by using the 'IllegalArgumentException'
 * for values less than zero.
 * 
 */           
    public static double sumTo(int n) {
        
        if (n < 0) {        //if 'n' is negative, an exception object is constructed using new keyword.

            throw new IllegalArgumentException("value is less than zero and not allowed: " + n);

        }
        if (n == 0) {       // the base case to ensure recursion is not infinite.
                            // conditional expression returning a double '0.0' if 'n' equals 0.
            return 0.0;

        } else {

            return 1.0 / n + sumTo(n-1);        // the reciprocal of 'n' is returned
                                                // and recursively returns the result of 
        }                                       // 'sumTo()' method when 'n' is less than 1.
    }
}