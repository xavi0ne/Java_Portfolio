/**
 * 
 * The Anagram class performs a boolean operation to identify if the Strings
 * passed to the 'isAnagram()' method is a true anagram. The String is 
 * processed to ensure characters are all lowercase and punctuation is ignored
 * to perform a true validation whether the Strings are anagram. A helper method
 * 'ignorePunctuation()' is used to assist with the conversion of the String using
 * the 'Character.isLetterOrDigit()' in its operation. 
 * 
* *@author Xavier Torres
* @Version Last modified on 09_19_24
* 
* @credit: Building Java Programs, 
*      by Stuart Reges and Marty Stenn, 
*      pg. 1890 - 1896.
*/

import java.util.Arrays;
import java.lang.Character;

public class Anagram {

    public static void main(String [] args) {   

        System.out.printf("isAnagram(%s, %s) = %s\n", "pots", "Stop!", isAnagram("pots", "Stop!"));

    }

/**
 * The 'isAnagram()' method performs a boolean operation to identify if the Strings passed from the main method 
 * is an anagram. The method uses a helper method 'ignorePunctuation' to assist with the String process and 
 * ensure the Strings punctuation to include '!' is ignored during comparison. A conditional expresion is then
 * used to compare the two Strings length, to return false if not equal in length. Then the '.toCharArray()' and 
 * the '.sort()' are used to process the characters to bring forth the result using the '.equals()' method and
 * evaluate whether they are anagrams or are not anagrams. 
 */

    public static boolean isAnagram(String stringArg1, String stringArg2) {

        stringArg1 = ignorePunctuation(stringArg1.toLowerCase());
        stringArg2 = ignorePunctuation(stringArg2.toLowerCase());
        
        if (stringArg1.length() != stringArg2.length()) {

            return false;
        }

        char[] str1Length = stringArg1.toCharArray();
        char[] str2Length = stringArg2.toCharArray();

        Arrays.sort(str1Length);
        Arrays.sort(str2Length);

        return Arrays.equals(str1Length, str2Length);
    }

/**
 * The 'ignorePunctuation' method is a helper method used to perform
 * the processing of the String using StringBuilder to create an object
 * instance and using that in a for loop to evaluate each of the characters;
 * to convert them to ignore punctuation using the '.isLetterOrDigit()' through
 * the conditional expression. The new String is then appended and returned using
 * '.toString()' to be used by the 'isAnagram()' method in finalizing the boolean
 * operation and determine if Strings are anagram or are not anagram. 
 */
    private static String ignorePunctuation(String str) {

        StringBuilder sb = new StringBuilder();
        for (char c : str.toCharArray()) {

            if (Character.isLetterOrDigit(c)) {

                sb.append(c);
            }
        }
        return sb.toString();
    }
}