/**
 * 
 * The Palindrome class performs a recursive solution to determine
 * whether a sentence is or is not a palindrome. Using the Scanner class
 * to capture user input, the main method creates an object instance of 
 * Scanner and stores it in the 'userKeyboard' variable. A StringBuilder
 * instance object called 'str' is created and a loop expression is done to 
 * count the characters of the string, convert to lowercase and remove 
 * punctuation using '.isLetterOrDigit()'. The updated String 'str' is 
 * then passed to the 'isPalindrome()' method call. 
 * 
 * @author Xavier Torres
 * @Version Last modified on 09_19_24
 * 
  @credit: Building Java Programs, 
 *      by Stuart Reges and Marty Stenn, 
 *      pg. 633-634.
 */

import java.util.*;
import java.util.Scanner;
import java.lang.Character;

public class Palindrome {

    public static void main (String [] args) {

        String userInputString;

        Scanner userKeyboard = new Scanner(System.in);      //the userKeyboard variable is created by instantiating an object using the new keyword.
                                                            //the userKeyboard variable now points to the newly created constructor instance of the Scanner class.
                                                            //the args 'System.in' is used so the instance can get and store the user input. 

        System.out.print("Type a String value for userInputString: ");       //user is prompted.

        userInputString = userKeyboard.nextLine();      // used to get entire input line and remove token from buffer.

        StringBuilder str = new StringBuilder();
        for (char ch : userInputString.toCharArray()) {

            if (Character.isLetterOrDigit(ch)) {        //converts user input by removing punctuation and 
                                                        // converts to all lowercase.
                str.append(Character.toLowerCase(ch));
            }
        }

        System.out.printf("isPalindrome(%s) = %s\n", userInputString, isPalindrome(str.toString()));       //'%s' indicates a String placeholder and '\n' 
                                                                                                            // indicates an escape with new line. 
    }

    public static boolean isPalindrome (String s) {

        if (s.length() <= 1) {      //the base case is a conditional expression to execute 
            return true;            //when the argument 's' is less or equal to one. 
        } else {
            
            if (s.charAt(0) == s.charAt(s.length()-1)) {        //compares the first and last char in s and if equal. 

                
                return isPalindrome(s.substring(1, s.length() - 1));        //returns result recursively to determine 
            }                                                               //if substring of s (from 1st to last) is palindrome.
        }
        return false;
    }
}