/**
 * 
 * The LowestGrade class calls two methods passing actual parameters which represent 
 * the scores of a single student. The 'removeLowest()' method then performs loops and 
 * conditional expressions to remove the lowest score from the array and ensure special
 * cases such as only one score and zero scores and not removed. The 'arrayPrint()' method
 * uses StringBuilder to build the array using the values passed from the main method call. 
 * 
 * @author Xavier Torres
 * @Version Last modified on 09_14_24
 * 
 * @credit: Building Java Programs, 
 *      by Stuart Reges and Marty Stenn, 
 *      pg. 1086-1087
 * 
 * @credit: Java 8 API docs, 
 *      the StringBuilder class, 
 *      url: https://docs.oracle.com/javase/8/docs/api/
 */

import java.lang.StringBuilder;

public class LowestGrade {

    public static void main (String [] args) {

        int [] a = removeLowest(23, 90, 47, 55, 88);
        int [] b = removeLowest(85);
        int [] c = removeLowest();
        int [] d = removeLowest(59, 92, 93, 47, 88, 47);

        System.out.printf("a = %s\n", arrayPrint(a));
        System.out.printf("b = %s\n", arrayPrint(b));
        System.out.printf("c = %s\n", arrayPrint(c));
        System.out.printf("d = %s\n", arrayPrint(d));

    }


/**The static method 'removeLowest()' accepts variable of integer named 'grades'
 * to represent scores of single student with special cases of returning an empty 
 * array when no score is passed, and not removing single grade. A new array is then
 * created to hold the same length of grades array minus the lowest score using looping
 * and conditional expressions.*/

    public static int [] removeLowest(int ... grades) {

        int lowestScore = 0;        
        for (int i = 1; i< grades.length; i++) {        //array is manipulated using traversal loop, using the
            if(grades[i] < grades[lowestScore]) {       //variable 'grades' to index each value and assigning index
                lowestScore = i;                        //based on conditional expression to the 'lowestScore' variable.
            }
        }

        if (grades.length == 0) {       //conditional expression to ensure special case where no grade is provided.
            
            return new int[0];          //to return an empty array and avoid erroring out. 
        } 

        if (grades.length == 1) {       //conditional expression for special case to 
                                        //ensure single grade is not removed.
            return grades;
        }

        int[] results = new int[grades.length -1];     //created new array named results with same length minus one as grades array.
        for (int i = 0, j = 0; i < grades.length; i++) {        //for loop iterates over each index in grades array
            if (i != lowestScore) {                             // index 'i' is for grades array; 'j' is for results array.
                results[j++] = grades[i];       //conditional expression validates current index to ensure it's not
            }                                   //the lowest and if true increments to results array after assignment.
        }

        return results;
    }

/**The arrayPrint method passes a variable integer called values which then
 * creates an object instance using the StringBuilder class and performs looping
 * to build an array based on the length of values provided using the '.appends()'. 
 * Conditional expression is used to remove lowest score from the array and returns
 * the final output.*/ 
    
    public static String arrayPrint(int[] values) {

        StringBuilder str = new StringBuilder("[");     //creates an object instance using the new key word and performs
            for (int i = 0; i < values.length; i++) {  //looping to build an array based on the length of values variable.
                str.append(values[i]);                  
                if (i < values.length - 1) {        //conditional expression is used to remove lowest score from the array 
                    str.append(",");                //and appends the comma.
                }
            }
            str.append("]");
            return str.toString();      //returns final output using the String Builder '.toString()' method. 
    }
}