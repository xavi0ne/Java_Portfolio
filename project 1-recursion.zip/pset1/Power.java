/**
 * 
 * The Power class performs a call to the modified power method with
 * actual parameters and then passes them to the power method header.
 * 
 * @author Xavier Torres
 * @version Last modified 09_07_24
 * 
 * credits: Building Java Programs, 
 *      by Stuart Reges and Marty Stenn, 
 *      pg. 1749 - 1754.
 */


public class Power {

    public static void main (String [] args) {
        
        power(2.0, 1024);
    }

    /**
     * The modified power method uses recursive approach with 
     * base case and recursive case to compute x^n with n using
     * even number of 1024. A variable was created to save the result
     * and then returns the result multiplying by itself. 
     */

    public static double power (double x, int n) {

        if (n == 0) return 1.0;     //the base case of recursive solution; stops recursion when n reaches 0.

        else if (n > 0) {
        
            if (n % 2 == 0) {      // remainder operator used to check if n is even.
                double powerTwo = power(x, n / 2);    //problem is reduced by half. 
                return powerTwo * powerTwo;      //result returned is multiplied by itself.
            
            } else {

                return x * power(x, n - 1);
            }

        } else {
            
             return 1.0 / power(x, - n);        //the modified power method is called 11 times total to compute (2.0, 1024).
        }
    }
}