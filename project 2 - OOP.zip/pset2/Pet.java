/**
 * The class Pet defines itself as abstract, meaning it is a type 
 * of class used by subclasses. It creates private variables to 
 * indicate the state or behavior of the Pet class, as well as 
 * three methods to define the actions the Pet class can 
 * perform. The constructor is defined using public in the header
 * and with parameters to be used. 
 * 
 * @author: Xavier Torres
 * 
 * @version: last updated on 10-1-24
 * 
 * @credit: Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              Pg. 1245 - 1258. 
 */

public abstract class Pet {

    private String name;

    private int year; 

    public Pet(String name, int year) {     // Created a constructor to initialize the new objects
                                            // as they are created in the 'PetTest.java' class 
        this.name = name;                   // using public on the header followed by class name 
        this.year = year;                   // and the parameters to be used. The 'this' keyword is 
    }                                       // used to refer to the implicit parameters inside the class.

/**
 * Declared as abstract with no body of code to be used by the subclasses 'Dog.java' and 'Cat.java'.
 */
    public abstract String speak();     

/**
 * Since the field 'name' is private, an accessor method is created 'getName()' that returns the field 'name', 
 * enabling other classes to have access to it. 
 * */                                       
    public String getName() {

        return name;      
    }                       
    public int getYear() {

        return year;
    }
}