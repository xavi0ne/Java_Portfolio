/**
 * 
 * The Ship abstract class performs inheritence and abstraction 
 * by providing a defined blueprint of instance field variables, 
 * declared with a 'private' access modifier. 
 * 
 * @author: Xavier Torres
 * 
 * @version: last modified on 09-27-24.
 * 
 * @Credit: Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              Pg. 1271 - 1275. 
 */

public abstract class Ship {

    private String shipName;
    private int shipYear;
    private MainEngine mainEngine;

    enum MainEngine { STEAM_ENGINE, STEAM_TURBINE, GAS_TURBINE, DIESEL,
                        ELECTRIC, WIND, HUMAN_FORCE };

    
/**
 * A constructor is 
 * created which calls a defined setter method named 'setAttributes'.
 */
    public Ship(String shipName, int shipYear, MainEngine mainEngine) {
      
        setAttributes(shipName, shipYear, mainEngine);
    }

    
/**
 * The getter methods 
 * 'getName' and 'getYear' return the private fields to enable
 * subclasses to access these fields without any ability to change
 * or modify them.
 */
    public String getName() {

        return shipName;
    }

    public int getYear() {

        return shipYear;
    }

/**
 * This method 'setAttributes' assigns the private fields to be 
 * accessed by subclasses when called upon.
 */

    public void setAttributes(String shipName, int getYear, MainEngine mainEngine) {

        this.shipName = shipName;
        this.shipYear = shipYear;
        this.mainEngine = mainEngine;

    }

/**
 * The 'toString()' method then returns the field variables in String format.
 */
    public String toString() {

        return  String.format ("%s, %s, %s\n", shipName + mainEngine + shipYear);
    }
}

/**
 * The CruiseShip class is a subclass of Ship and declares its 
 * special fields for 'maxPassengers' and 'norovirusOutbreak' in 
 * addition to the fields inherited by the superclass. 
 *
 * @author: Xavier Torres
 * 
 * @version: last modified on 09-27-24.
 * 
 * @Credit: Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              pg. 1352-1356
 */

class CruiseShip extends Ship {

    private int maxPassengers;

    private boolean norovirusOutbreak;


/**
 * the Constructor is created and calls the constructor of 'Ship' using 
 * the 'super()' method. This enables the 'Ship' class to properly initialize
 * before the subclass initializes, providing inheritence. 'Super()' is called 
 * first for that purpose. 
 */
    public CruiseShip(String shipName, int shipYear, MainEngine mainEngine, int
        maxPassengers, boolean norovirusOutbreak) {

        super(shipName, shipYear, mainEngine);

        this.maxPassengers = maxPassengers;

        this.norovirusOutbreak = norovirusOutbreak;
    }

    public int getMaxPassengers() {

        return maxPassengers;
    }

/**
 * The 'toString()' here has an Override keyword as a way to 
 * implement a new version of a method and replace code that
 * would be inherited from the 'Ship' superclass. 
 */
    @Override
    public String toString() {

        return "CruiseShip Name: " + getName() + ", maxPassengers: " + maxPassengers;
    }
}

/**
 * The CargoShip class is a subclass of Ship and declares its 
 * special field for 'capacity' of type double in 
 * addition to the fields inherited by the superclass. 
 *
 * @author: Xavier Torres
 * 
 * @version: last modified on 09-27-24.
 * 
 * @Credit: Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              pg. 1352-1356
 */

class CargoShip extends Ship {

    private double capacity;


/**
 * the Constructor is created and calls the constructor of 'Ship' using 
 * the 'super()' method. This enables the 'Ship' class to properly initialize
 * before the subclass initializes, providing inheritence. 'Super()' is called 
 * first for that purpose followed by the class field variable. 
 */
    public CargoShip(String shipName, int shipYear, MainEngine mainEngine, 
        double capacity) {

            super(shipName, shipYear, mainEngine);

            this.capacity = capacity;    
    }

    public double getCapacity() {

        return capacity;
    }

/**
 * The 'toString()' here has an Override keyword as a way to 
 * implement a new version of a method and replace code that
 * would be inherited from the 'Ship' superclass. 
 */
    @Override
    public String toString() {

        return "CargoShip Name: " + getName() + ", Cargo Capacity: " + capacity + " tons";
    }
}

/**
 * The TankerShip class is a subclass of CargoShip and declares its 
 * special field for 'oilCapacity' of type int in 
 * addition to the fields inherited by the superclass. 
 *
 * @author: Xavier Torres
 * 
 * @version: last modified on 09-27-24.
 * 
 * @Credit: Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              pg. 1352-1356
 */

class TankerShip extends CargoShip {

    private int oilCapacity;


/**
 * the Constructor is created and calls the constructor of 'Ship' using 
 * the 'super()' method. This enables the 'Ship' and 'CargoShip' class to properly initialize
 * before the subclass initializes, providing inheritence. 'Super()' is called 
 * first for that purpose followed by the class field variable. 
 */
    public TankerShip(String shipName, int shipYear, MainEngine mainEngine, double capacity, int oilCapacity) {

        super(shipName, shipYear, mainEngine, capacity);

        this.oilCapacity = oilCapacity;
    }

    public int getOilCapacity() {

        return oilCapacity;
    }

    public String toString() {

        return "TankerShip Name: " + getName() + ", Oil Capacity: " + oilCapacity + " Barrels";
    }
}