/**
 * The Bar Code class represents a postal bar code and performs 
 * the operations to convert a five digit zip code into an equivalent 
 * bar code. The Constructor created supports both encoding and decoding
 * operations from zip code to barcode as well as from bar code to zip code.
 * 
 * @author: Xavier Torres
 * 
 * @version: last updated on 10-4-24
 * 
 * @Credit:  Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              pg. 1220-1290 & 2554-2556
 */
public class BarCode {

    private String myZipCode;       // the instance variables are set to private to protect
                                    // the data from modification. 
    private String myBarCode;

    private static final String[] BAR_CODE_ARRAY = { "||:::", ":::||", "::|:|", "::||:",        // the 'BAR_CODE_ARRAY' constant was created to 
        ":|::|", ":|:|:", ":||::", "|:::|", "|::|:", "|:|::"};                                  // reduce redundancy in my code since it is 
                                                                                                // used in three of the methods within the class.
    public BarCode(String myZipCode) {                                                          // the keyword 'final' makes variable unchangeable.
                                                                                                
        if (myZipCode.length() == 5) {

            if (isValidZipCode(myZipCode)) {

                this.myZipCode = myZipCode;     
                this.myBarCode = encode(myZipCode);     // constructor created is set to public. This ensures the private instance 
                                                        // variables can be accessed indirectly without the ability to modify them.
            } else {

                throw new IllegalArgumentException("Illegal zip code values: " + myZipCode);
            }

        } else if (myZipCode.length() == 32) {

            if (isValidBarCode(myZipCode)) {

                this.myBarCode = myZipCode;     
                this.myZipCode = decode(myZipCode);     // the 'this()' keyword is used to distinguish params with
                                                        // same name as instance variables.
            } else {

                throw new IllegalArgumentException("Illegal bar code values: " + myZipCode);
            }

        } else {

            throw new IllegalArgumentException("Illegal bar code values: " + myZipCode);        //exception is thrown to control error handling.
        }
    }

/**
 * the 'getZipCode()' is defined with public access modifier and used 
 * to return the instance variable 'myZipCode'. This allows the private
 * variable to be accessible by other classes indirectly without the 
 * ability to modify the value. 
 */
    public String getZipCode() {

        return myZipCode;
    }

/**
 * the 'getBarCode()' is defined with public access modifier and used 
 * to return the instance variable 'myBarCode'. This allows the private
 * variable to be accessible by other classes indirectly without the 
 * ability to modify the value. 
 */

    public String getBarCode() {

        return myBarCode;
    }


/**
 * the 'digitToCode()' uses a conditional expression to ensure the 
 * digitCode variable is equal or greater than 0 and equal or less 
 * than 9, using error handling with IllegalArgumentException for values
 * not within 0-9 range. It also returns the five digit bar code that
 * represents the digit.
 */
    private String digitToCode(int digitCode) {

        if (digitCode < 0 || digitCode > 9) {

            throw new IllegalArgumentException("values must be between 0-9");
        }

        return BAR_CODE_ARRAY[digitCode];
    }

/**
 * the 'codeToDigit()' uses a conditional expression to ensure the param value
 * is exactly five character segments, using error handling if it is not. It 
 * uses a for loop iteration to return the corresponding codeDigit. 
 */
    private int codeToDigit(String codeDigit) {

        if (codeDigit.length() != 5) {

            throw new IllegalArgumentException("values must be exactly five character barcode segment");
        }
        
        for (int i = 0; i < BAR_CODE_ARRAY.length; i++) {

            if (BAR_CODE_ARRAY[i].equals(codeDigit)) {

                return i;
            }
        }
        return -1;
    }

/**
 * the 'isValidBarCode()' returns a boolean value after performing 
 * checks using conditional expression to ensure the 'myBarCode' variable starts and ends with a '|' 
 * and its length is within 32 characters. A loop iteration is performed
 * using 'codeToDigit()' to ensure the segment corresponds to digits within 
 * 0-9. If invalid, it returns false.  
 */
    private boolean isValidBarCode (String myBarCode) {

        if(myBarCode.length() != 32 || myBarCode.charAt(31) != '|' || myBarCode.charAt(0) != '|') {

            return false;
        }

        for (int i = 1; i <= 25; i += 5) {      //loop iteration is done starting with 2nd char and in 5 char segments,
                                                // ensuring proper checks for correct delimiters.
            String segment = myBarCode.substring(i, i + 5);
        
            if (codeToDigit(segment) == -1) {

                return false;
            }
        }

        return true;
    }

/**
 * the 'isValidZipCode()' performs checks to see if the 'myZipCode' variable
 * is within 5 digits using conditional expression and 
 * returns a boolean value after performing a loop iteration.  
 */
    private boolean isValidZipCode (String myZipCode) {

        if (myZipCode.length() !=5) {

            return false;
        }

        for (int i = 0; i < myZipCode.length(); i++) {

            if (!Character.isDigit(myZipCode.charAt(i))) {      // the loop iteration performs to ensure 'myZipCode'
                                                                // are digits by using conditional expression and the 
                return false;                                   // 'isDigit()' from the Character class to perform the check
            }
        }

        return true;
    }

/**
 * the 'getCheckDigit()' performs a loop iteration for the sum of the digits
 * to equal the next multiple of 10. It uses the '.getNumericValue()' from 
 * the Character class to perform this operation. 
 */
    private int getCheckDigit(String myZipCode) {

        int getSum = 0;

        for (int i = 0; i < myZipCode.length(); i++) {

            getSum += Character.getNumericValue(myZipCode.charAt(i));
        }

        int MultipleOfTen = (getSum + 9) / 10 * 10;     //expresion is used to get the next multiple of 10
                                                        // which is then stored in the variable.
        int checkDigit = MultipleOfTen - getSum;

        return checkDigit;
    }

/**
 * the 'encode()' method uses StringBuilder to start and end encoding
 * with a frame bar ("|"). An enhanced for loop is used to provide the sum
 * of all the digits in 'myZipCode' variable. The Character class is used 
 * to reference the 'getNumbericValue()' which is then stored in the 'total'
 * variable. A 'checkDigit' variable is initialized with an expression to make
 * the total the next multiple of 10.
 */
    private String encode(String myZipCode) {

        int total = 0;
        for (char digit : myZipCode.toCharArray()) {

            total += Character.getNumericValue(digit);
        }
        int checkDigit = (10 - (total % 10)) % 10;

        StringBuilder barCode = new StringBuilder("|");      // The String Builder then appends the 'digitToCode()',  
                                                                // using the Character class to reference the 'getNumericalValue()'
        for (char digit : myZipCode.toCharArray()) {            // with 'digit' stored, all within the enhanced for loop.

            barCode.append(digitToCode(Character.getNumericValue(digit)));
        }

        barCode.append(BAR_CODE_ARRAY[checkDigit]);
        barCode.append("|");

        return barCode.toString();
    }


/**
 * the 'decode()' performs checks using conditional expression to ensure the 'myBarCode' variable starts 
 * and ends with a '|' and its length is within 32 characters, returning an empty
 * String if invalid. It then uses StringBuilder and performs a loop iteration
 * to decode and return the 5 digit zip code as a String. The decode is performed by a loop 
 * iteration where the weights variable of type array int is used. A conditional
 * expression is used for special case involving the digit 0, where it appends 0 if the 
 * sum is 11, and if not true then simply appends the 'add' variable. 
 */
    private String decode(String myBarCode) {


        if (myBarCode.charAt(0) != '|' || myBarCode.length() != 32 || myBarCode.charAt(31) != '|' ) {

             return "";
            
        }
        
        myBarCode = myBarCode.substring(1, myBarCode.length() - 1);

        int[] weights = {7, 4, 2, 1, 0};        // the array is defined for decoding each 5-char segment.

        StringBuilder zipCode = new StringBuilder();

        for (int i = 0; i < myBarCode.length(); i += 5) {       //loop iteration is done through 'myBarCode' 
                                                                // variable in 5-char segments.
            String segment = myBarCode.substring(i, i + 5);

            int add = 0;
            
            for (int j = 0; j < segment.length(); j++) {

                if (segment.charAt(j) == '|') {

                    add += weights[j];      //weights is calculated based on the the delimiter '|'
                }                           // for each segment. 
            }

            if (add == 11) {

                zipCode.append(0);

            } else {

                zipCode.append(add);
            }
            
        }

        String checkDigitChars = zipCode.substring(0, zipCode.length() - 1);

        int checkDigit = Character.getNumericValue(zipCode.charAt(zipCode.length() - 1));

        int checkDigitSum = getCheckDigit(checkDigitChars);
        if (checkDigit != checkDigitSum) {

            throw new IllegalArgumentException("Illegal bar code values: " + myBarCode);        //zipCode is validated using the '.getNumericValue()'
        }                                                                                       // and stored in 'checDigit' variable, which then uses
                                                                                                // a conditional expression to check if digits do not match,
        return checkDigitChars;                                                                 // performing error handling by throwing IllegalArgumentException
    }                                                                                           // if no match. Otherwise, returns the decoded zipCode if checks pass.
}