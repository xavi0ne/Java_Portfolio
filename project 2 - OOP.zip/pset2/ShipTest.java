/**
 * 
 * The ShipTest class is a program class which performs the
 * operation of kickstarting the operations of these classes
 * using the main() method. An array object is created named
 * 'shipType' and initialized with the capacity of 6. An object
 * instance is then created for each with the field variables
 * inherited from the parent and child class relationship. A 
 * loop iteration is performed to print in String format the 
 * Ship names for each and its respective values.  
 * 
 * @author: Xavier Torres
 * 
 * @version: last modified on 09-27-24.
 * 
 * @Credit: Building Java Programs 5th Ed., 
 *              by Stuart Reges and Marty Stepp
 *              Pg. 1271 - 1275. 
 */

public class ShipTest {

    public static void main(String[] args) {

        Ship[] shipType = new Ship[6];

        shipType[0] = new CruiseShip("Royal Caribean", 2010, 
            Ship.MainEngine.ELECTRIC, 2400, false);

        shipType[1] = new CruiseShip("Tropical Sun", 2020, 
            Ship.MainEngine.DIESEL, 3500, false);

        shipType[2] = new CargoShip("Santa Maria", 2021, 
            Ship.MainEngine.GAS_TURBINE, 47000);

        shipType[3] = new CargoShip("La Pinta", 2020, 
            Ship.MainEngine.GAS_TURBINE, 52000);
        
        shipType[4] = new TankerShip("Dreamer", 1995, 
            Ship.MainEngine.DIESEL, 18000, 78000);

        shipType[5] = new TankerShip("Winner", 1998, 
            Ship.MainEngine.DIESEL, 19000, 100000);

        for (Ship kind : shipType) {

            System.out.printf("%s\n", kind.toString());
        }
    }
}